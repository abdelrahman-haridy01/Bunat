import * as i0 from '@angular/core';
import { EventEmitter, TemplateRef, AfterContentInit, OnDestroy, QueryList, ElementRef, AfterViewInit, OnChanges, ChangeDetectorRef } from '@angular/core';
import { ControlValueAccessor } from '@angular/forms';

declare class KsaaButtonComponent {
    /** Variant of the button */
    variant: 'primary' | 'secondary' | 'info' | 'danger' | 'custom';
    disabled: boolean;
    /** What background color to use */
    backgroundColor?: string;
    /** Optional text color override */
    textColor?: string;
    /** Optional border color override */
    borderColor?: string;
    /** Optional icon placed alongside the label */
    icon?: string;
    /** Optional icon source for image-based icons */
    iconSrc?: string;
    /** Icon position relative to the label */
    iconPosition: 'left' | 'right';
    /** Accessible label (useful when the visible label is empty) */
    ariaLabel?: string;
    /** How large should the button be? */
    size: 'small' | 'medium' | 'large';
    /**
     * Button contents
     *
     * @required
     */
    label: string;
    /** Optional click handler */
    onClick: EventEmitter<Event>;
    get classes(): string[];
    get inlineStyles(): Record<string, string> | null;
    static ɵfac: i0.ɵɵFactoryDeclaration<KsaaButtonComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KsaaButtonComponent, "ksaa-button", never, { "variant": { "alias": "variant"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "backgroundColor": { "alias": "backgroundColor"; "required": false; }; "textColor": { "alias": "textColor"; "required": false; }; "borderColor": { "alias": "borderColor"; "required": false; }; "icon": { "alias": "icon"; "required": false; }; "iconSrc": { "alias": "iconSrc"; "required": false; }; "iconPosition": { "alias": "iconPosition"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; "size": { "alias": "size"; "required": false; }; "label": { "alias": "label"; "required": false; }; }, { "onClick": "onClick"; }, never, never, true, never>;
}

type FooterLink = {
    label: string;
    href?: string;
    routePath?: string;
};
type FooterLinkGroup = {
    title: string;
    links: FooterLink[];
};
type FooterIconLink = {
    label: string;
    href?: string;
    imgSrc: string;
};
type FooterLogo = {
    label: string;
    src: string;
};
declare class FooterTemplateDirective {
    readonly template: TemplateRef<unknown>;
    type: 'groups' | 'social' | 'accessibility' | 'quickLinks' | 'meta' | 'logos';
    constructor(template: TemplateRef<unknown>);
    static ɵfac: i0.ɵɵFactoryDeclaration<FooterTemplateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<FooterTemplateDirective, "[pTemplate]", never, { "type": { "alias": "pTemplate"; "required": false; }; }, {}, never, never, true, never>;
}
declare class KsaaFooterComponent implements AfterContentInit, OnDestroy {
    locale: 'ar' | 'en';
    variant: 'primary' | 'gray';
    containerClass: string;
    groups?: FooterLinkGroup[];
    socialLinks?: FooterIconLink[];
    accessibilityLinks?: FooterIconLink[];
    quickLinks?: FooterLink[];
    policyLinks?: FooterLink[];
    logos?: FooterLogo[];
    socialHeadingOverride?: string;
    get socialHeading(): string;
    accessibilityHeadingOverride?: string;
    get accessibilityHeading(): string;
    set copyrightText(value: string | undefined);
    get copyrightText(): string | undefined;
    get dir(): 'rtl' | 'ltr';
    get resolvedGroups(): FooterLinkGroup[];
    get resolvedSocial(): FooterIconLink[];
    get resolvedAccessibility(): FooterIconLink[];
    get resolvedQuickLinks(): FooterLink[];
    get resolvedPolicyLinks(): FooterLink[];
    get resolvedLogos(): FooterLogo[];
    get hasGroups(): boolean;
    get hasSocial(): boolean;
    get hasAccessibility(): boolean;
    get hasQuickLinks(): boolean;
    get hasMeta(): boolean;
    get hasLogos(): boolean;
    projectedTemplates?: QueryList<FooterTemplateDirective>;
    projectedTemplateRefs?: QueryList<TemplateRef<unknown>>;
    resolvedGroupsTemplate?: TemplateRef<unknown>;
    resolvedSocialTemplate?: TemplateRef<unknown>;
    resolvedAccessibilityTemplate?: TemplateRef<unknown>;
    resolvedQuickLinksTemplate?: TemplateRef<unknown>;
    resolvedMetaTemplate?: TemplateRef<unknown>;
    resolvedLogosTemplate?: TemplateRef<unknown>;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    private _copyrightText?;
    private templateChangesSub?;
    private assignProjectedTemplates;
    static ɵfac: i0.ɵɵFactoryDeclaration<KsaaFooterComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KsaaFooterComponent, "ksaa-footer", never, { "locale": { "alias": "locale"; "required": false; }; "variant": { "alias": "variant"; "required": false; }; "containerClass": { "alias": "containerClass"; "required": false; }; "groups": { "alias": "groups"; "required": false; }; "socialLinks": { "alias": "socialLinks"; "required": false; }; "accessibilityLinks": { "alias": "accessibilityLinks"; "required": false; }; "quickLinks": { "alias": "quickLinks"; "required": false; }; "policyLinks": { "alias": "policyLinks"; "required": false; }; "logos": { "alias": "logos"; "required": false; }; "socialHeadingOverride": { "alias": "socialHeading"; "required": false; }; "accessibilityHeadingOverride": { "alias": "accessibilityHeading"; "required": false; }; "copyrightText": { "alias": "copyrightText"; "required": false; }; }, {}, ["projectedTemplates", "projectedTemplateRefs"], never, true, never>;
}

type NavbarLink = {
    label: string;
    href?: string;
    routePath?: string;
    active?: boolean;
    hasCaret?: boolean;
    children?: NavbarLink[];
};
type NavbarAction = {
    label?: string;
    icon?: string;
    variant?: 'primary' | 'outline' | 'custom';
};
declare class NavbarTemplateDirective {
    readonly template: TemplateRef<unknown>;
    type: 'startTemplate' | 'endTemplate';
    constructor(template: TemplateRef<unknown>);
    static ɵfac: i0.ɵɵFactoryDeclaration<NavbarTemplateDirective, never>;
    static ɵdir: i0.ɵɵDirectiveDeclaration<NavbarTemplateDirective, "[pTemplate]", never, { "type": { "alias": "pTemplate"; "required": false; }; }, {}, never, never, true, never>;
}
declare class KsaaNavbarComponent implements AfterContentInit, OnDestroy {
    private host;
    /** Text for the optional back action */
    backLabel?: string;
    /** Brand logo URL */
    brandLogoSrc?: string;
    /** Brand text label */
    brandLabel?: string;
    /** Array of navigation links */
    links: NavbarLink[];
    /** Optional actions rendered on the opposite side */
    actions: NavbarAction[];
    /** Custom template rendered in the start section */
    startTemplate?: TemplateRef<unknown>;
    /** Custom template rendered in the end section */
    endTemplate?: TemplateRef<unknown>;
    /** Render a muted background */
    muted: boolean;
    /** Render slim padding */
    dense: boolean;
    /** Add a light outline/border */
    outlined: boolean;
    /** Direction of the navbar */
    dir: 'rtl' | 'ltr';
    /** Optional aria-label override */
    ariaLabel?: string;
    contentStartTemplate?: TemplateRef<unknown>;
    contentEndTemplate?: TemplateRef<unknown>;
    projectedTemplates?: QueryList<NavbarTemplateDirective>;
    projectedContentTemplates?: QueryList<TemplateRef<unknown>>;
    menuOpen: boolean;
    private openSubmenus;
    private projectedStartTemplate?;
    private projectedEndTemplate?;
    private templateChangesSub?;
    constructor(host: ElementRef<HTMLElement>);
    get resolvedStartTemplate(): TemplateRef<unknown> | undefined;
    get resolvedEndTemplate(): TemplateRef<unknown> | undefined;
    ngAfterContentInit(): void;
    ngOnDestroy(): void;
    toggleMenu(): void;
    closeMenu(): void;
    toggleSubmenu(index: number): void;
    isSubmenuOpen(index: number): boolean;
    handleLinkClick(event: Event, link: NavbarLink, index: number): void;
    handleDocumentClick(event: Event): void;
    private closeAllSubmenus;
    private assignProjectedTemplates;
    static ɵfac: i0.ɵɵFactoryDeclaration<KsaaNavbarComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KsaaNavbarComponent, "ksaa-navbar", never, { "backLabel": { "alias": "backLabel"; "required": false; }; "brandLogoSrc": { "alias": "brandLogoSrc"; "required": false; }; "brandLabel": { "alias": "brandLabel"; "required": false; }; "links": { "alias": "links"; "required": false; }; "actions": { "alias": "actions"; "required": false; }; "startTemplate": { "alias": "startTemplate"; "required": false; }; "endTemplate": { "alias": "endTemplate"; "required": false; }; "muted": { "alias": "muted"; "required": false; }; "dense": { "alias": "dense"; "required": false; }; "outlined": { "alias": "outlined"; "required": false; }; "dir": { "alias": "dir"; "required": false; }; "ariaLabel": { "alias": "ariaLabel"; "required": false; }; }, {}, ["contentStartTemplate", "contentEndTemplate", "projectedTemplates", "projectedContentTemplates"], never, true, never>;
}

declare class KsaaCardComponent implements AfterContentInit {
    projectedNodes: QueryList<ElementRef>;
    hasProjectedContent: boolean;
    /** Title displayed at the top of the card */
    title?: string;
    /** Supporting description text */
    description?: string;
    /** Small muted line at the bottom for contextual hints */
    note?: string;
    /** Small label rendered next to the title */
    metaLabel?: string;
    /** Optional icon displayed in the header */
    cardIconSrc?: string;
    /** Enable selection affordance */
    selectable: boolean;
    /** Whether the card is currently selected */
    selected: boolean;
    /** Visual subdued background */
    muted: boolean;
    /** Disable interactions and apply disabled styling */
    disabled: boolean;
    /** Optional click handler */
    onClick: EventEmitter<Event>;
    ngAfterContentInit(): void;
    handleClick(event: Event): void;
    private updateProjectedContent;
    static ɵfac: i0.ɵɵFactoryDeclaration<KsaaCardComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KsaaCardComponent, "ksaa-card", never, { "title": { "alias": "title"; "required": false; }; "description": { "alias": "description"; "required": false; }; "note": { "alias": "note"; "required": false; }; "metaLabel": { "alias": "metaLabel"; "required": false; }; "cardIconSrc": { "alias": "cardIconSrc"; "required": false; }; "selectable": { "alias": "selectable"; "required": false; }; "selected": { "alias": "selected"; "required": false; }; "muted": { "alias": "muted"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; }, { "onClick": "onClick"; }, ["projectedNodes"], ["*"], true, never>;
}

declare class KsaaCheckboxComponent implements AfterViewInit, OnChanges, ControlValueAccessor {
    inputRef?: ElementRef<HTMLInputElement>;
    /** Checkbox label text */
    label?: string;
    /** Supporting description below the label */
    description?: string;
    /** Error or warning text displayed below */
    errorMessage?: string;
    /** Whether the checkbox is checked */
    checked: boolean;
    /** Whether the checkbox is in the indeterminate state */
    indeterminate: boolean;
    /** Disable interactions */
    disabled: boolean;
    /** Visual size of the checkbox */
    size: 'small' | 'medium' | 'large';
    /** Color treatment for the checkbox */
    variant: 'primary' | 'neutral';
    /** Emits when the checked state changes */
    checkedChange: EventEmitter<boolean>;
    /** Emits the native change event */
    onChange: EventEmitter<Event>;
    private onChangeFn;
    private onTouchedFn;
    ngAfterViewInit(): void;
    ngOnChanges(): void;
    handleChange(event: Event): void;
    writeValue(value: boolean): void;
    registerOnChange(fn: (value: boolean) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    markTouched(): void;
    private updateIndeterminate;
    static ɵfac: i0.ɵɵFactoryDeclaration<KsaaCheckboxComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KsaaCheckboxComponent, "ksaa-checkbox", never, { "label": { "alias": "label"; "required": false; }; "description": { "alias": "description"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "checked": { "alias": "checked"; "required": false; }; "indeterminate": { "alias": "indeterminate"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "size": { "alias": "size"; "required": false; }; "variant": { "alias": "variant"; "required": false; }; }, { "checkedChange": "checkedChange"; "onChange": "onChange"; }, never, never, true, never>;
}

declare class KsaaTextareaComponent implements ControlValueAccessor {
    /** Field label */
    label: string;
    /** Textarea value */
    value: string;
    /** Placeholder text */
    placeholder: string;
    /** Helper text below the textarea */
    helperText: string;
    /** Error message displayed below the textarea */
    errorMessage: string;
    /** Textarea name attribute */
    name?: string;
    /** Textarea id attribute */
    inputId?: string;
    /** Direction of the text flow */
    dir: 'ltr' | 'rtl';
    /** Visual size of the textarea */
    size: 'small' | 'medium' | 'large';
    /** Force a visual state for Storybook */
    state: 'default' | 'hover' | 'focus';
    /** Disable interactions */
    disabled: boolean;
    /** Mark the textarea as read-only */
    readonly: boolean;
    /** Shows a required indicator */
    required: boolean;
    /** Number of visible text lines */
    rows: number;
    /** Emits the current value */
    valueChange: EventEmitter<string>;
    /** Emits the native input event */
    onInput: EventEmitter<Event>;
    /** Emits the native blur event */
    onBlur: EventEmitter<Event>;
    isFocused: boolean;
    private onChangeFn;
    private onTouchedFn;
    get describedById(): string | null;
    handleInput(event: Event): void;
    handleFocus(): void;
    handleBlur(event: Event): void;
    writeValue(value: string): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<KsaaTextareaComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KsaaTextareaComponent, "ksaa-textarea", never, { "label": { "alias": "label"; "required": false; }; "value": { "alias": "value"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "helperText": { "alias": "helperText"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "name": { "alias": "name"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; "dir": { "alias": "dir"; "required": false; }; "size": { "alias": "size"; "required": false; }; "state": { "alias": "state"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "required": { "alias": "required"; "required": false; }; "rows": { "alias": "rows"; "required": false; }; }, { "valueChange": "valueChange"; "onInput": "onInput"; "onBlur": "onBlur"; }, never, never, true, never>;
}

declare class KsaaTextInputComponent implements ControlValueAccessor {
    /** Field label */
    label: string;
    /** Input value */
    value: string;
    /** Placeholder text */
    placeholder: string;
    /** Helper text below the input */
    helperText: string;
    /** Error message displayed below the input */
    errorMessage: string;
    /** Input type attribute */
    type: 'text' | 'email' | 'password' | 'search' | 'tel' | 'url';
    /** Input name attribute */
    name?: string;
    /** Input id attribute */
    inputId?: string;
    /** Direction of the text flow */
    dir: 'ltr' | 'rtl';
    /** Visual size of the input */
    size: 'small' | 'medium' | 'large';
    /** Force a visual state for Storybook */
    state: 'default' | 'hover' | 'focus';
    /** Disable interactions */
    disabled: boolean;
    /** Mark the input as read-only */
    readonly: boolean;
    /** Shows a required indicator */
    required: boolean;
    /** Emits the current value */
    valueChange: EventEmitter<string>;
    /** Emits the native input event */
    onInput: EventEmitter<Event>;
    /** Emits the native blur event */
    onBlur: EventEmitter<Event>;
    isFocused: boolean;
    private onChangeFn;
    private onTouchedFn;
    get describedById(): string | null;
    handleInput(event: Event): void;
    handleFocus(): void;
    handleBlur(event: Event): void;
    writeValue(value: string): void;
    registerOnChange(fn: (value: string) => void): void;
    registerOnTouched(fn: () => void): void;
    setDisabledState(isDisabled: boolean): void;
    static ɵfac: i0.ɵɵFactoryDeclaration<KsaaTextInputComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KsaaTextInputComponent, "ksaa-text-input", never, { "label": { "alias": "label"; "required": false; }; "value": { "alias": "value"; "required": false; }; "placeholder": { "alias": "placeholder"; "required": false; }; "helperText": { "alias": "helperText"; "required": false; }; "errorMessage": { "alias": "errorMessage"; "required": false; }; "type": { "alias": "type"; "required": false; }; "name": { "alias": "name"; "required": false; }; "inputId": { "alias": "inputId"; "required": false; }; "dir": { "alias": "dir"; "required": false; }; "size": { "alias": "size"; "required": false; }; "state": { "alias": "state"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "readonly": { "alias": "readonly"; "required": false; }; "required": { "alias": "required"; "required": false; }; }, { "valueChange": "valueChange"; "onInput": "onInput"; "onBlur": "onBlur"; }, never, never, true, never>;
}

declare class KsaaModalComponent {
    private static nextId;
    /** Modal title text */
    title?: string;
    /** Supporting description below the title */
    description?: string;
    /** Direction of the modal content */
    dir: 'ltr' | 'rtl';
    /** Modal size width */
    size: 'small' | 'medium' | 'large';
    /** Action buttons layout */
    actionsLayout: 'horizontal' | 'stacked';
    /** Position within its container */
    position: 'top-center' | 'center' | 'bottom-center';
    /** Display the leading icon */
    showIcon: boolean;
    /** Icon text rendered inside the leading badge */
    iconText: string;
    /** Accessible label for the close button */
    closeLabel: string;
    /** Toggle the close button */
    showClose: boolean;
    /** Base id used for aria attributes */
    modalId: string;
    /** Emits when the close icon is clicked */
    onClose: EventEmitter<Event>;
    get titleId(): string;
    get descriptionId(): string;
    static ɵfac: i0.ɵɵFactoryDeclaration<KsaaModalComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KsaaModalComponent, "ksaa-modal", never, { "title": { "alias": "title"; "required": false; }; "description": { "alias": "description"; "required": false; }; "dir": { "alias": "dir"; "required": false; }; "size": { "alias": "size"; "required": false; }; "actionsLayout": { "alias": "actionsLayout"; "required": false; }; "position": { "alias": "position"; "required": false; }; "showIcon": { "alias": "showIcon"; "required": false; }; "iconText": { "alias": "iconText"; "required": false; }; "closeLabel": { "alias": "closeLabel"; "required": false; }; "showClose": { "alias": "showClose"; "required": false; }; "modalId": { "alias": "modalId"; "required": false; }; }, { "onClose": "onClose"; }, never, ["*", "[modal-actions]"], true, never>;
}

declare class KsaaAccordionComponent implements AfterViewInit {
    private readonly cdr;
    contentSlot?: ElementRef<HTMLElement>;
    titleSlot?: ElementRef<HTMLElement>;
    hasProjectedContent: boolean;
    hasProjectedTitle: boolean;
    /** Accordion heading label */
    title: string;
    /** Supporting content shown when expanded */
    description: string;
    /** Toggle expanded state */
    expanded: boolean;
    /** Apply muted surface styling */
    muted: boolean;
    /** Disable the accordion */
    disabled: boolean;
    /** Force hovered state for documentation */
    hovered: boolean;
    /** Force focused state for documentation */
    focused: boolean;
    /** Text direction */
    dir: 'ltr' | 'rtl';
    /** Emits when the accordion is toggled */
    toggled: EventEmitter<boolean>;
    constructor(cdr: ChangeDetectorRef);
    ngAfterViewInit(): void;
    toggle(): void;
    private updateProjectedContent;
    private hasMeaningfulNodes;
    static ɵfac: i0.ɵɵFactoryDeclaration<KsaaAccordionComponent, never>;
    static ɵcmp: i0.ɵɵComponentDeclaration<KsaaAccordionComponent, "ksaa-accordion", never, { "title": { "alias": "title"; "required": false; }; "description": { "alias": "description"; "required": false; }; "expanded": { "alias": "expanded"; "required": false; }; "muted": { "alias": "muted"; "required": false; }; "disabled": { "alias": "disabled"; "required": false; }; "hovered": { "alias": "hovered"; "required": false; }; "focused": { "alias": "focused"; "required": false; }; "dir": { "alias": "dir"; "required": false; }; }, { "toggled": "toggled"; }, never, ["[accordion-title]", "*"], true, never>;
}

export { FooterTemplateDirective, KsaaAccordionComponent, KsaaButtonComponent, KsaaCardComponent, KsaaCheckboxComponent, KsaaFooterComponent, KsaaModalComponent, KsaaNavbarComponent, KsaaTextInputComponent, KsaaTextareaComponent, NavbarTemplateDirective };
