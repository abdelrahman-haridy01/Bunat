import * as i1 from '@angular/common';
import { CommonModule } from '@angular/common';
import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, Component, Directive, TemplateRef, ContentChildren, ChangeDetectionStrategy, ViewEncapsulation, HostListener, ContentChild, ElementRef, forwardRef, ViewChild } from '@angular/core';
import * as i2 from '@angular/router';
import { RouterModule } from '@angular/router';
import { Subscription } from 'rxjs';
import { NG_VALUE_ACCESSOR } from '@angular/forms';

class KsaaButtonComponent {
    /** Variant of the button */
    variant = 'primary';
    disabled = false;
    /** What background color to use */
    backgroundColor;
    /** Optional text color override */
    textColor;
    /** Optional border color override */
    borderColor;
    /** Optional icon placed alongside the label */
    icon;
    /** Optional icon source for image-based icons */
    iconSrc;
    /** Icon position relative to the label */
    iconPosition = 'left';
    /** Accessible label (useful when the visible label is empty) */
    ariaLabel;
    /** How large should the button be? */
    size = 'medium';
    /**
     * Button contents
     *
     * @required
     */
    label = 'Button';
    /** Optional click handler */
    onClick = new EventEmitter();
    get classes() {
        const mode = `ksaa-button--${this.variant}`;
        return [
            'ksaa-button',
            `ksaa-button--${this.size}`,
            mode,
            this.disabled ? 'ksaa-button--disabled' : '',
        ].filter(Boolean);
    }
    get inlineStyles() {
        const styles = {};
        if (this.backgroundColor) {
            styles['background-color'] = this.backgroundColor;
        }
        if (this.textColor) {
            styles['color'] = this.textColor;
        }
        if (this.borderColor) {
            styles['border-color'] = this.borderColor;
        }
        return Object.keys(styles).length ? styles : null;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaButtonComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.3", type: KsaaButtonComponent, isStandalone: true, selector: "ksaa-button", inputs: { variant: "variant", disabled: "disabled", backgroundColor: "backgroundColor", textColor: "textColor", borderColor: "borderColor", icon: "icon", iconSrc: "iconSrc", iconPosition: "iconPosition", ariaLabel: "ariaLabel", size: "size", label: "label" }, outputs: { onClick: "onClick" }, ngImport: i0, template: ` <button
    type="button"
    (click)="onClick.emit($event)"
    [ngClass]="classes"
    [ngStyle]="inlineStyles"
    [disabled]="disabled"
    [attr.aria-label]="ariaLabel || label"
  >
    <span
      *ngIf="(icon || iconSrc) && iconPosition === 'left'"
      class="ksaa-button__icon"
      aria-hidden="true"
    >
      <img *ngIf="iconSrc; else leftIconText" [src]="iconSrc" class="ksaa-button__icon-image" alt="" />
      <ng-template #leftIconText>{{ icon }}</ng-template>
    </span>
    <span *ngIf="label" class="ksaa-button__label">{{ label }}</span>
    <span
      *ngIf="(icon || iconSrc) && iconPosition === 'right'"
      class="ksaa-button__icon"
      aria-hidden="true"
    >
      <img *ngIf="iconSrc; else rightIconText" [src]="iconSrc" class="ksaa-button__icon-image" alt="" />
      <ng-template #rightIconText>{{ icon }}</ng-template>
    </span>
  </button>`, isInline: true, styles: [".ksaa-button{display:inline-flex;align-items:center;justify-content:center;gap:var(--spacing-xs);cursor:pointer;border:1px solid transparent;border-radius:var(--radius-sm);font-weight:var(--text-sm-semibold-font-weight);line-height:var(--text-sm-regular-line-height);font-family:var(--font-family-ibm-plex-sans-arabic);transition:background-color .18s ease,color .18s ease,box-shadow .18s ease,border-color .18s ease,transform .12s ease;box-shadow:0 1px 2px #0000000d}.ksaa-button__icon{display:inline-flex;align-items:center;justify-content:center}.ksaa-button__icon-image{width:1em;height:1em;object-fit:contain}.ksaa-button__label{display:inline-flex;align-items:center;justify-content:center}.ksaa-button--primary{background-color:var(--color-primary-default);color:var(--color-oncolor-primary);border-color:var(--color-primary-default)}.ksaa-button--primary:hover{background-color:var(--color-primary-sa-flag);border-color:var(--color-primary-sa-flag)}.ksaa-button--info{background-color:var(--color-info-default);color:var(--color-oncolor-info);border-color:var(--color-info-default)}.ksaa-button--info:hover{background-color:var(--color-info-dark);border-color:var(--color-info-dark)}.ksaa-button--danger{background-color:var(--color-error-default);color:var(--color-oncolor-error);border-color:var(--color-error-default)}.ksaa-button--danger:hover{background-color:var(--color-error-dark);border-color:var(--color-error-dark)}.ksaa-button--secondary{background-color:var(--color-neutral-default);color:var(--color-default);border-color:var(--color-neutral-secondary);box-shadow:0 1px 2px #0000000d,0 0 0 1px #e5e7ebb3}.ksaa-button--secondary:hover{background-color:var(--color-body-hover)}.ksaa-button--custom{background-color:transparent;color:var(--color-primary-default);border-color:transparent}.ksaa-button--custom:hover{background-color:var(--color-oncolor-transparent-30);color:var(--color-primary-sa-flag)}.ksaa-button--small{padding:var(--spacing-sm) var(--spacing-lg);font-size:var(--text-xs-medium-font-size)}.ksaa-button--medium{padding:var(--spacing-md) var(--spacing-xl);font-size:var(--text-sm-medium-font-size)}.ksaa-button--large{padding:var(--spacing-lg) var(--spacing-4xl);font-size:var(--text-md-medium-font-size)}.ksaa-button--disabled,.ksaa-button[disabled]{cursor:not-allowed;opacity:.56;box-shadow:none;transform:none;background-color:var(--color-neutral-default);color:var(--color-neutral-400);border-color:var(--color-neutral-secondary)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgStyle, selector: "[ngStyle]", inputs: ["ngStyle"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaButtonComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ksaa-button', standalone: true, imports: [CommonModule], template: ` <button
    type="button"
    (click)="onClick.emit($event)"
    [ngClass]="classes"
    [ngStyle]="inlineStyles"
    [disabled]="disabled"
    [attr.aria-label]="ariaLabel || label"
  >
    <span
      *ngIf="(icon || iconSrc) && iconPosition === 'left'"
      class="ksaa-button__icon"
      aria-hidden="true"
    >
      <img *ngIf="iconSrc; else leftIconText" [src]="iconSrc" class="ksaa-button__icon-image" alt="" />
      <ng-template #leftIconText>{{ icon }}</ng-template>
    </span>
    <span *ngIf="label" class="ksaa-button__label">{{ label }}</span>
    <span
      *ngIf="(icon || iconSrc) && iconPosition === 'right'"
      class="ksaa-button__icon"
      aria-hidden="true"
    >
      <img *ngIf="iconSrc; else rightIconText" [src]="iconSrc" class="ksaa-button__icon-image" alt="" />
      <ng-template #rightIconText>{{ icon }}</ng-template>
    </span>
  </button>`, styles: [".ksaa-button{display:inline-flex;align-items:center;justify-content:center;gap:var(--spacing-xs);cursor:pointer;border:1px solid transparent;border-radius:var(--radius-sm);font-weight:var(--text-sm-semibold-font-weight);line-height:var(--text-sm-regular-line-height);font-family:var(--font-family-ibm-plex-sans-arabic);transition:background-color .18s ease,color .18s ease,box-shadow .18s ease,border-color .18s ease,transform .12s ease;box-shadow:0 1px 2px #0000000d}.ksaa-button__icon{display:inline-flex;align-items:center;justify-content:center}.ksaa-button__icon-image{width:1em;height:1em;object-fit:contain}.ksaa-button__label{display:inline-flex;align-items:center;justify-content:center}.ksaa-button--primary{background-color:var(--color-primary-default);color:var(--color-oncolor-primary);border-color:var(--color-primary-default)}.ksaa-button--primary:hover{background-color:var(--color-primary-sa-flag);border-color:var(--color-primary-sa-flag)}.ksaa-button--info{background-color:var(--color-info-default);color:var(--color-oncolor-info);border-color:var(--color-info-default)}.ksaa-button--info:hover{background-color:var(--color-info-dark);border-color:var(--color-info-dark)}.ksaa-button--danger{background-color:var(--color-error-default);color:var(--color-oncolor-error);border-color:var(--color-error-default)}.ksaa-button--danger:hover{background-color:var(--color-error-dark);border-color:var(--color-error-dark)}.ksaa-button--secondary{background-color:var(--color-neutral-default);color:var(--color-default);border-color:var(--color-neutral-secondary);box-shadow:0 1px 2px #0000000d,0 0 0 1px #e5e7ebb3}.ksaa-button--secondary:hover{background-color:var(--color-body-hover)}.ksaa-button--custom{background-color:transparent;color:var(--color-primary-default);border-color:transparent}.ksaa-button--custom:hover{background-color:var(--color-oncolor-transparent-30);color:var(--color-primary-sa-flag)}.ksaa-button--small{padding:var(--spacing-sm) var(--spacing-lg);font-size:var(--text-xs-medium-font-size)}.ksaa-button--medium{padding:var(--spacing-md) var(--spacing-xl);font-size:var(--text-sm-medium-font-size)}.ksaa-button--large{padding:var(--spacing-lg) var(--spacing-4xl);font-size:var(--text-md-medium-font-size)}.ksaa-button--disabled,.ksaa-button[disabled]{cursor:not-allowed;opacity:.56;box-shadow:none;transform:none;background-color:var(--color-neutral-default);color:var(--color-neutral-400);border-color:var(--color-neutral-secondary)}\n"] }]
        }], propDecorators: { variant: [{
                type: Input
            }], disabled: [{
                type: Input
            }], backgroundColor: [{
                type: Input
            }], textColor: [{
                type: Input
            }], borderColor: [{
                type: Input
            }], icon: [{
                type: Input
            }], iconSrc: [{
                type: Input
            }], iconPosition: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], size: [{
                type: Input
            }], label: [{
                type: Input
            }], onClick: [{
                type: Output
            }] } });

class FooterTemplateDirective {
    template;
    type;
    constructor(template) {
        this.template = template;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: FooterTemplateDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.0.3", type: FooterTemplateDirective, isStandalone: true, selector: "[pTemplate]", inputs: { type: ["pTemplate", "type"] }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: FooterTemplateDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pTemplate]', standalone: true }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { type: [{
                type: Input,
                args: ['pTemplate']
            }] } });
class KsaaFooterComponent {
    locale = 'ar';
    variant = 'gray';
    containerClass = 'container';
    groups;
    socialLinks;
    accessibilityLinks;
    quickLinks;
    policyLinks;
    logos;
    socialHeadingOverride;
    get socialHeading() {
        return this.socialHeadingOverride ?? (this.locale === 'ar' ? 'تواصل معنا' : 'Social Media');
    }
    accessibilityHeadingOverride;
    get accessibilityHeading() {
        return (this.accessibilityHeadingOverride ??
            (this.locale === 'ar' ? 'أدوات الإتاحة والوصول' : 'Accessibility Tools'));
    }
    set copyrightText(value) {
        this._copyrightText = value;
    }
    get copyrightText() {
        return this._copyrightText;
    }
    get dir() {
        return this.locale === 'ar' ? 'rtl' : 'ltr';
    }
    get resolvedGroups() {
        return this.groups ?? [];
    }
    get resolvedSocial() {
        return this.socialLinks ?? [];
    }
    get resolvedAccessibility() {
        return this.accessibilityLinks ?? [];
    }
    get resolvedQuickLinks() {
        return this.quickLinks ?? [];
    }
    get resolvedPolicyLinks() {
        return this.policyLinks ?? [];
    }
    get resolvedLogos() {
        return this.logos ?? [];
    }
    get hasGroups() {
        return Boolean(this.resolvedGroupsTemplate || this.resolvedGroups.length);
    }
    get hasSocial() {
        return Boolean(this.resolvedSocialTemplate || this.resolvedSocial.length);
    }
    get hasAccessibility() {
        return Boolean(this.resolvedAccessibilityTemplate || this.resolvedAccessibility.length);
    }
    get hasQuickLinks() {
        return Boolean(this.resolvedQuickLinksTemplate || this.resolvedQuickLinks.length);
    }
    get hasMeta() {
        return Boolean(this.resolvedMetaTemplate || this.copyrightText || this.resolvedPolicyLinks.length);
    }
    get hasLogos() {
        return Boolean(this.resolvedLogosTemplate || this.resolvedLogos.length);
    }
    projectedTemplates;
    projectedTemplateRefs;
    resolvedGroupsTemplate;
    resolvedSocialTemplate;
    resolvedAccessibilityTemplate;
    resolvedQuickLinksTemplate;
    resolvedMetaTemplate;
    resolvedLogosTemplate;
    ngAfterContentInit() {
        this.assignProjectedTemplates();
        this.templateChangesSub = new Subscription();
        this.templateChangesSub.add(this.projectedTemplates?.changes.subscribe(() => this.assignProjectedTemplates()));
        this.templateChangesSub.add(this.projectedTemplateRefs?.changes.subscribe(() => this.assignProjectedTemplates()));
    }
    ngOnDestroy() {
        this.templateChangesSub?.unsubscribe();
    }
    _copyrightText;
    templateChangesSub;
    assignProjectedTemplates() {
        const templates = {};
        if (this.projectedTemplates?.length) {
            this.projectedTemplates.forEach((template) => {
                templates[template.type] = template.template;
            });
        }
        else {
            this.projectedTemplateRefs?.forEach((template) => {
                const type = template.elementRef.nativeElement?.getAttribute?.('pTemplate');
                if (type) {
                    templates[type] = template;
                }
            });
        }
        this.resolvedGroupsTemplate = templates['groups'];
        this.resolvedSocialTemplate = templates['social'];
        this.resolvedAccessibilityTemplate = templates['accessibility'];
        this.resolvedQuickLinksTemplate = templates['quickLinks'];
        this.resolvedMetaTemplate = templates['meta'];
        this.resolvedLogosTemplate = templates['logos'];
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaFooterComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.3", type: KsaaFooterComponent, isStandalone: true, selector: "ksaa-footer", inputs: { locale: "locale", variant: "variant", containerClass: "containerClass", groups: "groups", socialLinks: "socialLinks", accessibilityLinks: "accessibilityLinks", quickLinks: "quickLinks", policyLinks: "policyLinks", logos: "logos", socialHeadingOverride: ["socialHeading", "socialHeadingOverride"], accessibilityHeadingOverride: ["accessibilityHeading", "accessibilityHeadingOverride"], copyrightText: "copyrightText" }, queries: [{ propertyName: "projectedTemplates", predicate: FooterTemplateDirective, descendants: true }, { propertyName: "projectedTemplateRefs", predicate: TemplateRef, descendants: true }], ngImport: i0, template: `
    <footer
      class="ksaa-footer"
      [ngClass]="{
        'ksaa-footer--primary': variant === 'primary',
        'ksaa-footer--gray': variant === 'gray'
      }"
      [attr.dir]="dir"
      role="contentinfo"
    >
      <div [ngClass]="containerClass">
        <div class="ksaa-footer__top">
          <div class="ksaa-footer__groups" *ngIf="hasGroups">
            <ng-container
              *ngIf="resolvedGroupsTemplate; else defaultGroups"
              [ngTemplateOutlet]="resolvedGroupsTemplate"
            ></ng-container>
            <ng-template #defaultGroups>
              <div class="ksaa-footer__group" *ngFor="let group of resolvedGroups">
                <h3 class="ksaa-footer__group-title">{{ group.title }}</h3>
                <div class="ksaa-footer__divider"></div>
                <ul class="ksaa-footer__group-list">
                  <li *ngFor="let link of group.links">
                    <ng-container *ngIf="link.routePath; else groupHref">
                      <a class="ksaa-footer__link" [routerLink]="link.routePath">
                        {{ link.label }}
                      </a>
                    </ng-container>
                    <ng-template #groupHref>
                      <a class="ksaa-footer__link" [href]="link.href || '#'" target="_blank">{{
                        link.label
                      }}</a>
                    </ng-template>
                  </li>
                </ul>
              </div>
            </ng-template>
          </div>

          <div class="ksaa-footer__aside">
            <div class="ksaa-footer__aside-block" *ngIf="hasSocial">
              <ng-container
                *ngIf="resolvedSocialTemplate; else defaultSocial"
                [ngTemplateOutlet]="resolvedSocialTemplate"
              ></ng-container>
              <ng-template #defaultSocial>
                <h4 class="ksaa-footer__aside-title">{{ socialHeading }}</h4>
                <div class="ksaa-footer__divider"></div>
                <div class="ksaa-footer__icon-grid">
                  <a
                    *ngFor="let link of resolvedSocial"
                    class="ksaa-footer__icon-button"
                    [href]="link.href || '#'"
                    [attr.aria-label]="link.label"
                    target="_blank"
                  >
                    <img
                      class="ksaa-footer__icon"
                      [src]="link.imgSrc"
                      [alt]="link.label"
                      [title]="link.label"
                    />
                  </a>
                </div>
              </ng-template>
            </div>

            <div class="ksaa-footer__aside-block" *ngIf="hasAccessibility">
              <ng-container
                *ngIf="resolvedAccessibilityTemplate; else defaultAccessibility"
                [ngTemplateOutlet]="resolvedAccessibilityTemplate"
              ></ng-container>
              <ng-template #defaultAccessibility>
                <h4 class="ksaa-footer__aside-title">{{ accessibilityHeading }}</h4>
                <div class="ksaa-footer__divider"></div>

                <div class="ksaa-footer__icon-grid">
                  <a
                    *ngFor="let link of resolvedAccessibility"
                    class="ksaa-footer__icon-button"
                    [href]="link.href || '#'"
                    [attr.aria-label]="link.label"
                    target="_blank"
                  >
                    <img
                      class="ksaa-footer__icon"
                      [src]="link.imgSrc"
                      [alt]="link.label"
                      [title]="link.label"
                    />
                  </a>
                </div>
              </ng-template>
            </div>
          </div>
        </div>

        <div class="ksaa-footer__quick-links" *ngIf="hasQuickLinks">
          <ng-container
            *ngIf="resolvedQuickLinksTemplate; else defaultQuickLinks"
            [ngTemplateOutlet]="resolvedQuickLinksTemplate"
          ></ng-container>
          <ng-template #defaultQuickLinks>
            <ng-container *ngFor="let link of resolvedQuickLinks">
              <ng-container *ngIf="link.routePath; else quickHref">
                <a class="ksaa-footer__quick-link" [routerLink]="link.routePath">
                  {{ link.label }}
                </a>
              </ng-container>
              <ng-template #quickHref>
                <a class="ksaa-footer__quick-link" [href]="link.href || '#'" target="_blank">{{
                  link.label
                }}</a>
              </ng-template>
            </ng-container>
          </ng-template>
        </div>

        <div class="ksaa-footer__bottom">
          <div class="ksaa-footer__meta" *ngIf="hasMeta">
            <ng-container
              *ngIf="resolvedMetaTemplate; else defaultMeta"
              [ngTemplateOutlet]="resolvedMetaTemplate"
            ></ng-container>
            <ng-template #defaultMeta>
              <p class="ksaa-footer__copyright" *ngIf="copyrightText">
                {{ copyrightText }}
              </p>
              <div class="ksaa-footer__policies" *ngIf="resolvedPolicyLinks.length">
                <ng-container *ngFor="let link of resolvedPolicyLinks">
                  <ng-container *ngIf="link.routePath; else policyHref">
                    <a class="ksaa-footer__policy-link" [routerLink]="link.routePath">
                      {{ link.label }}
                    </a>
                  </ng-container>
                  <ng-template #policyHref>
                    <a class="ksaa-footer__policy-link" [href]="link.href || '#'" target="_blank">
                      {{ link.label }}
                    </a>
                  </ng-template>
                </ng-container>
              </div>
            </ng-template>
          </div>
          <div class="ksaa-footer__logos" *ngIf="hasLogos">
            <ng-container
              *ngIf="resolvedLogosTemplate; else defaultLogos"
              [ngTemplateOutlet]="resolvedLogosTemplate"
            ></ng-container>
            <ng-template #defaultLogos>
              <div class="ksaa-footer__logo" *ngFor="let logo of resolvedLogos">
                <img [src]="logo.src" [alt]="logo.label" loading="lazy" [title]="logo.label" />
              </div>
            </ng-template>
          </div>
        </div>
      </div>
    </footer>
  `, isInline: true, styles: [":host{display:block;width:100%;font-family:IBM Plex Sans Arabic,Arial,sans-serif}.container{margin:0 auto}.ksaa-footer{padding:40px 32px 24px;background:var(--color-gray-50);color:var(--color-gray-800)}.ksaa-footer--primary{background:var(--color-primary-sa-flag);color:var(--color-white)}.ksaa-footer--gray{background:var(--color-gray-50);color:var(--color-gray-800)}.ksaa-footer__top{display:flex;gap:32px;align-items:flex-start;justify-content:space-between}.ksaa-footer__groups{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:24px;flex:1}.ksaa-footer__group-title{font-size:14px;font-weight:700;margin:0 0 10px}.ksaa-footer__group-list{list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:8px}.ksaa-footer__link{font-size:13px;text-decoration:none}.ksaa-footer--primary .ksaa-footer__link{color:var(--color-white)}.ksaa-footer--gray .ksaa-footer__link{color:var(--color-gray-800)}.ksaa-footer__link:hover,.ksaa-footer__link:focus-visible{opacity:1;text-decoration:underline;outline:none}.ksaa-footer__aside{display:flex;flex-direction:column;gap:20px;min-width:180px}.ksaa-footer__aside-block{display:flex;flex-direction:column}.ksaa-footer__aside-title{font-size:13px;font-weight:700}.ksaa-footer__icon-grid{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.ksaa-footer__icon-button{width:32px;height:32px;border-radius:8px;border:1px solid rgba(255,255,255,.25);display:inline-flex;align-items:center;justify-content:center;background:transparent;color:inherit;text-decoration:none}.ksaa-footer--gray .ksaa-footer__icon-button{border-color:var(--color-gray-200)}.ksaa-footer__icon-button:hover,.ksaa-footer__icon-button:focus-visible{outline:none;background:#ffffff1f}.ksaa-footer--gray .ksaa-footer__icon-button:hover,.ksaa-footer--gray .ksaa-footer__icon-button:focus-visible{background:var(--color-gray-100)}.ksaa-footer__icon{width:14px;height:14px;object-fit:contain}.ksaa-footer__divider{height:1px;background:#ffffff29;margin:10px 0 6px}.ksaa-footer--gray .ksaa-footer__divider{background:var(--color-gray-200)}.ksaa-footer__quick-links{display:flex;flex-wrap:wrap;gap:18px;font-size:12px;margin-top:100px}.ksaa-footer__quick-link{color:inherit;text-decoration:underline}.ksaa-footer__quick-link:hover,.ksaa-footer__quick-link:focus-visible{text-decoration:underline;outline:none}.ksaa-footer__bottom{margin-top:20px;display:flex;flex-wrap:wrap;gap:20px;justify-content:space-between;align-items:flex-end}.ksaa-footer__meta{display:flex;flex-direction:column;gap:8px;font-size:12px}.ksaa-footer__copyright{margin:0;font-weight:600}.ksaa-footer--gray .ksaa-footer__copyright{color:var(--color-gray-800)}.ksaa-footer--primary .ksaa-footer__copyright{color:var(--color-white)}.ksaa-footer__policies{display:flex;gap:16px;flex-wrap:wrap}.ksaa-footer__policy-link{color:inherit;text-decoration:none;opacity:.8}.ksaa-footer__policy-link:hover,.ksaa-footer__policy-link:focus-visible{opacity:1;text-decoration:underline;outline:none}.ksaa-footer__logos{display:flex;gap:10px;flex-wrap:wrap}.ksaa-footer__logo{min-width:110px;height:44px;border-radius:8px;border:1px solid rgba(255,255,255,.3);display:inline-flex;align-items:center;justify-content:center;font-size:11px;padding:6px 8px;background:var(--color-white)}.ksaa-footer--gray .ksaa-footer__logo{border-color:var(--color-gray-200);background:var(--color-white);color:var(--color-gray-700)}.ksaa-footer__logo img{height:100%;max-height:32px;max-width:100%;object-fit:contain}@media(max-width:1024px){.ksaa-footer__top{flex-direction:column}.ksaa-footer__aside{flex-direction:row;gap:28px}.ksaa-footer__aside-block{flex:1 1 220px}.ksaa-footer__groups{display:flex;flex-wrap:wrap}.ksaa-footer__groups .ksaa-footer__group{width:130px}}@media(max-width:720px){.ksaa-footer{padding:24px 20px}.ksaa-footer__aside{flex-direction:row;flex-wrap:wrap;gap:24px}.ksaa-footer__quick-links{margin-top:40px;justify-content:center}.ksaa-footer__bottom{flex-direction:column;align-items:center;text-align:center}.ksaa-footer__meta{align-items:center}.ksaa-footer__logos{width:100%;justify-content:space-between}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush, encapsulation: i0.ViewEncapsulation.None });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaFooterComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ksaa-footer', standalone: true, imports: [CommonModule, RouterModule, FooterTemplateDirective], template: `
    <footer
      class="ksaa-footer"
      [ngClass]="{
        'ksaa-footer--primary': variant === 'primary',
        'ksaa-footer--gray': variant === 'gray'
      }"
      [attr.dir]="dir"
      role="contentinfo"
    >
      <div [ngClass]="containerClass">
        <div class="ksaa-footer__top">
          <div class="ksaa-footer__groups" *ngIf="hasGroups">
            <ng-container
              *ngIf="resolvedGroupsTemplate; else defaultGroups"
              [ngTemplateOutlet]="resolvedGroupsTemplate"
            ></ng-container>
            <ng-template #defaultGroups>
              <div class="ksaa-footer__group" *ngFor="let group of resolvedGroups">
                <h3 class="ksaa-footer__group-title">{{ group.title }}</h3>
                <div class="ksaa-footer__divider"></div>
                <ul class="ksaa-footer__group-list">
                  <li *ngFor="let link of group.links">
                    <ng-container *ngIf="link.routePath; else groupHref">
                      <a class="ksaa-footer__link" [routerLink]="link.routePath">
                        {{ link.label }}
                      </a>
                    </ng-container>
                    <ng-template #groupHref>
                      <a class="ksaa-footer__link" [href]="link.href || '#'" target="_blank">{{
                        link.label
                      }}</a>
                    </ng-template>
                  </li>
                </ul>
              </div>
            </ng-template>
          </div>

          <div class="ksaa-footer__aside">
            <div class="ksaa-footer__aside-block" *ngIf="hasSocial">
              <ng-container
                *ngIf="resolvedSocialTemplate; else defaultSocial"
                [ngTemplateOutlet]="resolvedSocialTemplate"
              ></ng-container>
              <ng-template #defaultSocial>
                <h4 class="ksaa-footer__aside-title">{{ socialHeading }}</h4>
                <div class="ksaa-footer__divider"></div>
                <div class="ksaa-footer__icon-grid">
                  <a
                    *ngFor="let link of resolvedSocial"
                    class="ksaa-footer__icon-button"
                    [href]="link.href || '#'"
                    [attr.aria-label]="link.label"
                    target="_blank"
                  >
                    <img
                      class="ksaa-footer__icon"
                      [src]="link.imgSrc"
                      [alt]="link.label"
                      [title]="link.label"
                    />
                  </a>
                </div>
              </ng-template>
            </div>

            <div class="ksaa-footer__aside-block" *ngIf="hasAccessibility">
              <ng-container
                *ngIf="resolvedAccessibilityTemplate; else defaultAccessibility"
                [ngTemplateOutlet]="resolvedAccessibilityTemplate"
              ></ng-container>
              <ng-template #defaultAccessibility>
                <h4 class="ksaa-footer__aside-title">{{ accessibilityHeading }}</h4>
                <div class="ksaa-footer__divider"></div>

                <div class="ksaa-footer__icon-grid">
                  <a
                    *ngFor="let link of resolvedAccessibility"
                    class="ksaa-footer__icon-button"
                    [href]="link.href || '#'"
                    [attr.aria-label]="link.label"
                    target="_blank"
                  >
                    <img
                      class="ksaa-footer__icon"
                      [src]="link.imgSrc"
                      [alt]="link.label"
                      [title]="link.label"
                    />
                  </a>
                </div>
              </ng-template>
            </div>
          </div>
        </div>

        <div class="ksaa-footer__quick-links" *ngIf="hasQuickLinks">
          <ng-container
            *ngIf="resolvedQuickLinksTemplate; else defaultQuickLinks"
            [ngTemplateOutlet]="resolvedQuickLinksTemplate"
          ></ng-container>
          <ng-template #defaultQuickLinks>
            <ng-container *ngFor="let link of resolvedQuickLinks">
              <ng-container *ngIf="link.routePath; else quickHref">
                <a class="ksaa-footer__quick-link" [routerLink]="link.routePath">
                  {{ link.label }}
                </a>
              </ng-container>
              <ng-template #quickHref>
                <a class="ksaa-footer__quick-link" [href]="link.href || '#'" target="_blank">{{
                  link.label
                }}</a>
              </ng-template>
            </ng-container>
          </ng-template>
        </div>

        <div class="ksaa-footer__bottom">
          <div class="ksaa-footer__meta" *ngIf="hasMeta">
            <ng-container
              *ngIf="resolvedMetaTemplate; else defaultMeta"
              [ngTemplateOutlet]="resolvedMetaTemplate"
            ></ng-container>
            <ng-template #defaultMeta>
              <p class="ksaa-footer__copyright" *ngIf="copyrightText">
                {{ copyrightText }}
              </p>
              <div class="ksaa-footer__policies" *ngIf="resolvedPolicyLinks.length">
                <ng-container *ngFor="let link of resolvedPolicyLinks">
                  <ng-container *ngIf="link.routePath; else policyHref">
                    <a class="ksaa-footer__policy-link" [routerLink]="link.routePath">
                      {{ link.label }}
                    </a>
                  </ng-container>
                  <ng-template #policyHref>
                    <a class="ksaa-footer__policy-link" [href]="link.href || '#'" target="_blank">
                      {{ link.label }}
                    </a>
                  </ng-template>
                </ng-container>
              </div>
            </ng-template>
          </div>
          <div class="ksaa-footer__logos" *ngIf="hasLogos">
            <ng-container
              *ngIf="resolvedLogosTemplate; else defaultLogos"
              [ngTemplateOutlet]="resolvedLogosTemplate"
            ></ng-container>
            <ng-template #defaultLogos>
              <div class="ksaa-footer__logo" *ngFor="let logo of resolvedLogos">
                <img [src]="logo.src" [alt]="logo.label" loading="lazy" [title]="logo.label" />
              </div>
            </ng-template>
          </div>
        </div>
      </div>
    </footer>
  `, encapsulation: ViewEncapsulation.None, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;width:100%;font-family:IBM Plex Sans Arabic,Arial,sans-serif}.container{margin:0 auto}.ksaa-footer{padding:40px 32px 24px;background:var(--color-gray-50);color:var(--color-gray-800)}.ksaa-footer--primary{background:var(--color-primary-sa-flag);color:var(--color-white)}.ksaa-footer--gray{background:var(--color-gray-50);color:var(--color-gray-800)}.ksaa-footer__top{display:flex;gap:32px;align-items:flex-start;justify-content:space-between}.ksaa-footer__groups{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:24px;flex:1}.ksaa-footer__group-title{font-size:14px;font-weight:700;margin:0 0 10px}.ksaa-footer__group-list{list-style:none;padding:0;margin:0;display:flex;flex-direction:column;gap:8px}.ksaa-footer__link{font-size:13px;text-decoration:none}.ksaa-footer--primary .ksaa-footer__link{color:var(--color-white)}.ksaa-footer--gray .ksaa-footer__link{color:var(--color-gray-800)}.ksaa-footer__link:hover,.ksaa-footer__link:focus-visible{opacity:1;text-decoration:underline;outline:none}.ksaa-footer__aside{display:flex;flex-direction:column;gap:20px;min-width:180px}.ksaa-footer__aside-block{display:flex;flex-direction:column}.ksaa-footer__aside-title{font-size:13px;font-weight:700}.ksaa-footer__icon-grid{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}.ksaa-footer__icon-button{width:32px;height:32px;border-radius:8px;border:1px solid rgba(255,255,255,.25);display:inline-flex;align-items:center;justify-content:center;background:transparent;color:inherit;text-decoration:none}.ksaa-footer--gray .ksaa-footer__icon-button{border-color:var(--color-gray-200)}.ksaa-footer__icon-button:hover,.ksaa-footer__icon-button:focus-visible{outline:none;background:#ffffff1f}.ksaa-footer--gray .ksaa-footer__icon-button:hover,.ksaa-footer--gray .ksaa-footer__icon-button:focus-visible{background:var(--color-gray-100)}.ksaa-footer__icon{width:14px;height:14px;object-fit:contain}.ksaa-footer__divider{height:1px;background:#ffffff29;margin:10px 0 6px}.ksaa-footer--gray .ksaa-footer__divider{background:var(--color-gray-200)}.ksaa-footer__quick-links{display:flex;flex-wrap:wrap;gap:18px;font-size:12px;margin-top:100px}.ksaa-footer__quick-link{color:inherit;text-decoration:underline}.ksaa-footer__quick-link:hover,.ksaa-footer__quick-link:focus-visible{text-decoration:underline;outline:none}.ksaa-footer__bottom{margin-top:20px;display:flex;flex-wrap:wrap;gap:20px;justify-content:space-between;align-items:flex-end}.ksaa-footer__meta{display:flex;flex-direction:column;gap:8px;font-size:12px}.ksaa-footer__copyright{margin:0;font-weight:600}.ksaa-footer--gray .ksaa-footer__copyright{color:var(--color-gray-800)}.ksaa-footer--primary .ksaa-footer__copyright{color:var(--color-white)}.ksaa-footer__policies{display:flex;gap:16px;flex-wrap:wrap}.ksaa-footer__policy-link{color:inherit;text-decoration:none;opacity:.8}.ksaa-footer__policy-link:hover,.ksaa-footer__policy-link:focus-visible{opacity:1;text-decoration:underline;outline:none}.ksaa-footer__logos{display:flex;gap:10px;flex-wrap:wrap}.ksaa-footer__logo{min-width:110px;height:44px;border-radius:8px;border:1px solid rgba(255,255,255,.3);display:inline-flex;align-items:center;justify-content:center;font-size:11px;padding:6px 8px;background:var(--color-white)}.ksaa-footer--gray .ksaa-footer__logo{border-color:var(--color-gray-200);background:var(--color-white);color:var(--color-gray-700)}.ksaa-footer__logo img{height:100%;max-height:32px;max-width:100%;object-fit:contain}@media(max-width:1024px){.ksaa-footer__top{flex-direction:column}.ksaa-footer__aside{flex-direction:row;gap:28px}.ksaa-footer__aside-block{flex:1 1 220px}.ksaa-footer__groups{display:flex;flex-wrap:wrap}.ksaa-footer__groups .ksaa-footer__group{width:130px}}@media(max-width:720px){.ksaa-footer{padding:24px 20px}.ksaa-footer__aside{flex-direction:row;flex-wrap:wrap;gap:24px}.ksaa-footer__quick-links{margin-top:40px;justify-content:center}.ksaa-footer__bottom{flex-direction:column;align-items:center;text-align:center}.ksaa-footer__meta{align-items:center}.ksaa-footer__logos{width:100%;justify-content:space-between}}\n"] }]
        }], propDecorators: { locale: [{
                type: Input
            }], variant: [{
                type: Input
            }], containerClass: [{
                type: Input
            }], groups: [{
                type: Input
            }], socialLinks: [{
                type: Input
            }], accessibilityLinks: [{
                type: Input
            }], quickLinks: [{
                type: Input
            }], policyLinks: [{
                type: Input
            }], logos: [{
                type: Input
            }], socialHeadingOverride: [{
                type: Input,
                args: ['socialHeading']
            }], accessibilityHeadingOverride: [{
                type: Input,
                args: ['accessibilityHeading']
            }], copyrightText: [{
                type: Input
            }], projectedTemplates: [{
                type: ContentChildren,
                args: [FooterTemplateDirective, { descendants: true }]
            }], projectedTemplateRefs: [{
                type: ContentChildren,
                args: [TemplateRef, { descendants: true }]
            }] } });

class NavbarTemplateDirective {
    template;
    type;
    constructor(template) {
        this.template = template;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: NavbarTemplateDirective, deps: [{ token: i0.TemplateRef }], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.0.3", type: NavbarTemplateDirective, isStandalone: true, selector: "[pTemplate]", inputs: { type: ["pTemplate", "type"] }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: NavbarTemplateDirective, decorators: [{
            type: Directive,
            args: [{ selector: '[pTemplate]', standalone: true }]
        }], ctorParameters: () => [{ type: i0.TemplateRef }], propDecorators: { type: [{
                type: Input,
                args: ['pTemplate']
            }] } });
class KsaaNavbarComponent {
    host;
    /** Text for the optional back action */
    backLabel;
    /** Brand logo URL */
    brandLogoSrc;
    /** Brand text label */
    brandLabel;
    /** Array of navigation links */
    links = [];
    /** Optional actions rendered on the opposite side */
    actions = [];
    /** Custom template rendered in the start section */
    startTemplate;
    /** Custom template rendered in the end section */
    endTemplate;
    /** Render a muted background */
    muted = false;
    /** Render slim padding */
    dense = false;
    /** Add a light outline/border */
    outlined = true;
    /** Direction of the navbar */
    dir = 'rtl';
    /** Optional aria-label override */
    ariaLabel;
    contentStartTemplate;
    contentEndTemplate;
    projectedTemplates;
    projectedContentTemplates;
    menuOpen = false;
    openSubmenus = new Set();
    projectedStartTemplate;
    projectedEndTemplate;
    templateChangesSub;
    constructor(host) {
        this.host = host;
    }
    get resolvedStartTemplate() {
        return this.projectedStartTemplate || this.contentStartTemplate || this.startTemplate;
    }
    get resolvedEndTemplate() {
        return this.projectedEndTemplate || this.contentEndTemplate || this.endTemplate;
    }
    ngAfterContentInit() {
        this.assignProjectedTemplates();
        const templateChanges = new Subscription();
        const projectedTemplatesChanges = this.projectedTemplates?.changes.subscribe(() => this.assignProjectedTemplates());
        const contentTemplatesChanges = this.projectedContentTemplates?.changes.subscribe(() => this.assignProjectedTemplates());
        if (projectedTemplatesChanges) {
            templateChanges.add(projectedTemplatesChanges);
        }
        if (contentTemplatesChanges) {
            templateChanges.add(contentTemplatesChanges);
        }
        this.templateChangesSub = templateChanges;
    }
    ngOnDestroy() {
        this.templateChangesSub?.unsubscribe();
    }
    toggleMenu() {
        this.menuOpen = !this.menuOpen;
    }
    closeMenu() {
        this.menuOpen = false;
        this.closeAllSubmenus();
    }
    toggleSubmenu(index) {
        if (this.openSubmenus.has(index)) {
            this.openSubmenus.delete(index);
        }
        else {
            this.openSubmenus.clear();
            this.openSubmenus.add(index);
        }
    }
    isSubmenuOpen(index) {
        return this.openSubmenus.has(index);
    }
    handleLinkClick(event, link, index) {
        if (link.children?.length) {
            event.preventDefault();
            this.toggleSubmenu(index);
        }
    }
    handleDocumentClick(event) {
        const target = event.target;
        if (!target) {
            return;
        }
        if (!this.host.nativeElement.contains(target)) {
            this.closeAllSubmenus();
        }
    }
    closeAllSubmenus() {
        this.openSubmenus.clear();
    }
    assignProjectedTemplates() {
        const templates = {};
        this.projectedTemplates?.forEach((template) => {
            templates[template.type] = template.template;
        });
        this.projectedStartTemplate = templates['startTemplate'];
        this.projectedEndTemplate = templates['endTemplate'];
        if (this.projectedStartTemplate || this.projectedEndTemplate) {
            return;
        }
        const fallbackTemplates = this.projectedContentTemplates?.toArray() ?? [];
        if (!this.projectedStartTemplate && fallbackTemplates.length > 0) {
            this.projectedStartTemplate = fallbackTemplates[0];
        }
        if (!this.projectedEndTemplate && fallbackTemplates.length > 1) {
            this.projectedEndTemplate = fallbackTemplates[1];
        }
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaNavbarComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.3", type: KsaaNavbarComponent, isStandalone: true, selector: "ksaa-navbar", inputs: { backLabel: "backLabel", brandLogoSrc: "brandLogoSrc", brandLabel: "brandLabel", links: "links", actions: "actions", startTemplate: "startTemplate", endTemplate: "endTemplate", muted: "muted", dense: "dense", outlined: "outlined", dir: "dir", ariaLabel: "ariaLabel" }, host: { listeners: { "document:click": "handleDocumentClick($event)" } }, queries: [{ propertyName: "contentStartTemplate", first: true, predicate: ["startTemplate"], descendants: true, read: TemplateRef }, { propertyName: "contentEndTemplate", first: true, predicate: ["endTemplate"], descendants: true, read: TemplateRef }, { propertyName: "projectedTemplates", predicate: NavbarTemplateDirective }, { propertyName: "projectedContentTemplates", predicate: TemplateRef }], ngImport: i0, template: `
    <nav
      class="ksaa-navbar"
      [ngClass]="{
        'ksaa-navbar--outlined': outlined,
        'ksaa-navbar--dense': dense,
        'ksaa-navbar--muted': muted,
        'ksaa-navbar--menu-open': menuOpen
      }"
      [attr.dir]="dir"
      role="navigation"
      [attr.aria-label]="ariaLabel || 'شريط التصفح'"
    >
      <div class="container">
        <div class="ksaa-navbar__section ksaa-navbar__section--start">
          <ng-container
            *ngIf="resolvedStartTemplate"
            [ngTemplateOutlet]="resolvedStartTemplate"
          ></ng-container>

          <button *ngIf="backLabel" class="ksaa-navbar__back" type="button">
            <span class="ksaa-navbar__back-icon" aria-hidden="true">←</span>
            <span class="ksaa-navbar__back-label">{{ backLabel }}</span>
          </button>

          <div *ngIf="brandLogoSrc || brandLabel" class="ksaa-navbar__brand">
            <img
              *ngIf="brandLogoSrc"
              class="ksaa-navbar__logo"
              [src]="brandLogoSrc"
              [alt]="brandLabel"
              loading="lazy"
            />
            <span *ngIf="brandLabel" class="ksaa-navbar__brand-text">{{ brandLabel }}</span>
          </div>

          <button
            class="ksaa-navbar__menu"
            type="button"
            aria-label="تبديل القائمة"
            (click)="toggleMenu()"
            [attr.aria-expanded]="menuOpen"
          >
            <span class="ksaa-navbar__menu-icon" aria-hidden="true">{{
              menuOpen ? '✕' : '☰'
            }}</span>
          </button>
        </div>

        <div class="ksaa-navbar__panel" [ngClass]="{ 'ksaa-navbar__panel--open': menuOpen }">
          <ul *ngIf="links?.length" class="ksaa-navbar__links" aria-label="التنقل الأساسي">
            <li
              *ngFor="let link of links; let i = index"
              class="ksaa-navbar__link"
              [ngClass]="{
                'ksaa-navbar__link--active': link.active,
                'ksaa-navbar__link--has-children': link.children?.length
              }"
            >
              <ng-container *ngIf="link.routePath; else navbarHref">
                <a
                  class="ksaa-navbar__link-content"
                  [routerLink]="link.routePath"
                  [attr.aria-haspopup]="link.children?.length ? 'true' : null"
                  (click)="handleLinkClick($event, link, i)"
                  [attr.aria-expanded]="link.children?.length ? isSubmenuOpen(i) : null"
                >
                  <span>{{ link.label }}</span>
                  <span *ngIf="link.children?.length" class="ksaa-navbar__caret" aria-hidden="true"
                    >▾</span
                  >
                </a>
              </ng-container>
              <ng-template #navbarHref>
                <a
                  class="ksaa-navbar__link-content"
                  [href]="link.href || '#'"
                  [attr.aria-haspopup]="link.children?.length ? 'true' : null"
                  (click)="handleLinkClick($event, link, i)"
                  [attr.aria-expanded]="link.children?.length ? isSubmenuOpen(i) : null"
                >
                  <span>{{ link.label }}</span>
                  <span *ngIf="link.children?.length" class="ksaa-navbar__caret" aria-hidden="true"
                    >▾</span
                  >
                </a>
              </ng-template>

              <ul
                *ngIf="link.children?.length"
                class="ksaa-navbar__submenu"
                aria-label="روابط فرعية"
                [ngClass]="{ 'ksaa-navbar__submenu--open': isSubmenuOpen(i) }"
              >
                <li *ngFor="let child of link.children" class="ksaa-navbar__submenu-item">
                  <ng-container *ngIf="child.routePath; else childHref">
                    <a class="ksaa-navbar__submenu-link" [routerLink]="child.routePath">
                      <span>{{ child.label }}</span>
                    </a>
                  </ng-container>
                  <ng-template #childHref>
                    <a class="ksaa-navbar__submenu-link" [href]="child.href || '#'">
                      <span>{{ child.label }}</span>
                    </a>
                  </ng-template>
                </li>
              </ul>
            </li>
          </ul>

          <div
            *ngIf="actions?.length || resolvedEndTemplate"
            class="ksaa-navbar__section ksaa-navbar__section--end"
          >
            <ng-container
              *ngIf="resolvedEndTemplate"
              [ngTemplateOutlet]="resolvedEndTemplate"
            ></ng-container>

            <button
              *ngFor="let action of actions"
              type="button"
              class="ksaa-navbar__action"
              [ngClass]="{
                'ksaa-navbar__action--primary': action.variant === 'primary',
                'ksaa-navbar__action--custom': action.variant === 'custom',
                'ksaa-navbar__action--outline': action.variant === 'outline'
              }"
            >
              <span *ngIf="action.icon" class="ksaa-navbar__action-icon" aria-hidden="true">{{
                action.icon
              }}</span>
              <span *ngIf="action.label">{{ action.label }}</span>
            </button>
          </div>
        </div>

        <button
          *ngIf="menuOpen"
          class="ksaa-navbar__overlay"
          type="button"
          aria-label="إغلاق القائمة"
          (click)="closeMenu()"
        ></button>
      </div>
    </nav>
  `, isInline: true, styles: [":host{display:block;width:100%}.ksaa-navbar .container{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:nowrap;padding:12px 0;background:var(--color-white);color:var(--color-gray-900);font-family:IBM Plex Sans Arabic,Arial,sans-serif;position:relative;margin:0 auto}.ksaa-navbar:not(.ksaa-navbar--outlined){border-bottom:1px solid var(--color-gray-200)}.ksaa-navbar--outlined{border:1px solid var(--color-gray-200);box-shadow:0 1px 0 0 var(--color-gray-200);border-radius:10px}.ksaa-navbar--muted{background:var(--color-gray-50)}.ksaa-navbar--dense{padding:8px 18px}.ksaa-navbar__section{display:inline-flex;align-items:center;gap:12px;min-width:0}.ksaa-navbar__section--start{flex:1;max-width:150px}.ksaa-navbar__section--end{justify-content:flex-end;flex:1;max-width:220px}.ksaa-navbar__brand{display:inline-flex;align-items:center;gap:10px;min-width:0}.ksaa-navbar__logo{width:120px;object-fit:contain}.ksaa-navbar__brand-text{font-weight:600;font-size:16px;color:var(--color-gray-900);white-space:nowrap}.ksaa-navbar__menu{display:none;align-items:center;justify-content:center;width:40px;height:40px;border-radius:10px;border:1px solid var(--color-gray-200);background:var(--color-white);color:var(--color-gray-900);cursor:pointer;transition:background .12s ease,color .12s ease}.ksaa-navbar__menu:hover,.ksaa-navbar__menu:focus-visible{background:var(--color-gray-100);outline:none}.ksaa-navbar__menu-icon{font-size:18px;line-height:1}.ksaa-navbar__links{list-style:none;display:inline-flex;align-items:center;gap:20px;margin:0;padding:0;flex-wrap:wrap;justify-content:flex-start;flex:0 1 auto}.ksaa-navbar__link{display:inline-flex;align-items:center;position:relative}.ksaa-navbar__link-content{display:inline-flex;align-items:center;gap:6px;color:var(--color-gray-600);font-weight:600;text-decoration:none;font-size:14px;padding:6px 4px;border-radius:8px;transition:color .12s ease,background .12s ease}.ksaa-navbar__link-content:hover,.ksaa-navbar__link-content:focus-visible{color:var(--color-slate-900);background:var(--color-gray-100);outline:none}.ksaa-navbar__link--active .ksaa-navbar__link-content{color:var(--color-primary-default)}.ksaa-navbar__caret{font-size:10px;transform:translateY(-1px)}.ksaa-navbar__submenu{display:none;position:absolute;inset-inline-start:0;top:calc(100% + 8px);min-width:200px;background:var(--color-white);border:1px solid var(--color-gray-200);box-shadow:0 10px 40px #0000000f;border-radius:10px;padding:10px 12px;flex-direction:column;gap:6px;z-index:2}.ksaa-navbar__submenu--open{display:flex}.ksaa-navbar__submenu-item{list-style:none}.ksaa-navbar__submenu-link{display:flex;align-items:center;gap:6px;color:var(--color-gray-900);text-decoration:none;font-size:14px;font-weight:600;padding:8px 10px;border-radius:8px;transition:background .12s ease,color .12s ease}.ksaa-navbar__submenu-link:hover,.ksaa-navbar__submenu-link:focus-visible{background:var(--color-gray-100);color:var(--color-slate-900);outline:none}.ksaa-navbar__back{display:inline-flex;align-items:center;gap:8px;background:transparent;border:1px solid var(--color-gray-200);border-radius:10px;padding:8px 12px;color:var(--color-primary-default);font-weight:700;cursor:pointer}.ksaa-navbar__back:hover,.ksaa-navbar__back:focus-visible{background:var(--color-success-light);outline:none}.ksaa-navbar__back-icon{font-size:14px;line-height:1}.ksaa-navbar__links+.ksaa-navbar__section--end,.ksaa-navbar__section--start+.ksaa-navbar__links{flex:1}.ksaa-navbar__panel{display:flex;align-items:center;justify-content:space-between;gap:16px;flex:1}.ksaa-navbar__panel--open{display:flex}.ksaa-navbar__section--end{display:inline-flex;align-items:center;gap:12px}.ksaa-navbar__action{border-radius:10px;padding:10px 16px;font-weight:700;font-size:14px;cursor:pointer;background:var(--color-white);border:1px solid var(--color-gray-200);color:var(--color-slate-900);transition:background .12s ease,color .12s ease,border-color .12s ease;display:inline-flex;align-items:center;gap:8px}.ksaa-navbar__action--primary{background:var(--color-primary-default);color:var(--color-white);border-color:var(--color-primary-default)}.ksaa-navbar__action--outline{background:var(--color-white);color:var(--color-primary-default);border-color:var(--color-primary-default)}.ksaa-navbar__action--custom{background:transparent;border-color:transparent;color:var(--color-primary-default)}.ksaa-navbar__action:hover,.ksaa-navbar__action:focus-visible{background:var(--color-success-light);outline:none}.ksaa-navbar__action--primary:hover,.ksaa-navbar__action--primary:focus-visible{background:var(--color-primary-sa-flag);color:var(--color-white)}.ksaa-navbar__action-icon{font-size:12px}@media(max-width:960px){.ksaa-navbar{flex-wrap:wrap;gap:10px}.ksaa-navbar__section--start,.ksaa-navbar__section--end{flex:1 1 100%;justify-content:space-between}.ksaa-navbar__links{flex:1 1 100%;justify-content:flex-start;gap:14px}.ksaa-navbar__panel{flex-wrap:wrap}}@media(max-width:640px){.ksaa-navbar{flex-direction:column;align-items:stretch;gap:12px;padding:12px 16px}.ksaa-navbar__section--start,.ksaa-navbar__section--end{flex:1 1 auto;width:100%}.ksaa-navbar__section--start{justify-content:space-between;max-width:100%}.ksaa-navbar__panel{flex-wrap:nowrap}.ksaa-navbar__section--end{justify-content:flex-start;flex-wrap:wrap;gap:8px}.ksaa-navbar__menu{display:inline-flex}.ksaa-navbar__panel{display:flex;position:fixed;inset-block:0;inset-inline-end:0;flex-direction:column;gap:12px;width:min(360px,90%);background:var(--color-white);border-inline-start:1px solid var(--color-gray-200);box-shadow:-12px 0 40px #0000001f;padding:20px 16px;z-index:3;transform:translate(calc(-100% + 24px));opacity:0;pointer-events:none;visibility:hidden;transition:transform .18s ease-in-out,box-shadow .18s ease-in-out,opacity .14s ease-in-out,visibility 0ms linear .18s;overflow-y:auto}.ksaa-navbar__panel--open{transform:translate(0);opacity:1;pointer-events:auto;visibility:visible;transition-delay:0ms}.ksaa-navbar__links{width:100%;flex-direction:column;align-items:stretch;gap:6px}.ksaa-navbar__link{width:100%;flex-wrap:wrap}.ksaa-navbar__link-content{width:100%;justify-content:space-between;white-space:normal;flex-wrap:wrap;border:1px solid var(--color-gray-200);border-radius:10px;padding:12px 14px}.ksaa-navbar__link-content[aria-expanded=true] .ksaa-navbar__caret{transform:rotate(180deg)}.ksaa-navbar__submenu{position:static;width:100%;display:flex;flex-direction:column;gap:8px;padding:0 10px;border:1px solid var(--color-gray-200);box-shadow:none;background:var(--color-slate-50);border-radius:12px;max-height:0;overflow:hidden;opacity:0;visibility:hidden;transform:translateY(-6px);transition:max-height .2s ease,opacity .16s ease,visibility 0ms linear .2s,transform .18s ease,padding .16s ease}.ksaa-navbar__submenu--open{max-height:560px;padding:8px 10px 10px;opacity:1;visibility:visible;transform:translateY(0);transition-delay:0ms}.ksaa-navbar__submenu-item+.ksaa-navbar__submenu-item{border-top:1px solid var(--color-gray-200);padding-top:8px;margin-top:4px}.ksaa-navbar__submenu-link{width:100%;flex-wrap:wrap;padding:8px 10px;background:transparent;border:none;color:var(--color-slate-900);font-weight:600;border-radius:10px}.ksaa-navbar__action{width:100%;justify-content:center}.ksaa-navbar__overlay{display:block;position:fixed;inset:0;background:#00000059;border:none;padding:0;margin:0;cursor:pointer;z-index:2}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgForOf, selector: "[ngFor][ngForOf]", inputs: ["ngForOf", "ngForTrackBy", "ngForTemplate"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }, { kind: "directive", type: i1.NgTemplateOutlet, selector: "[ngTemplateOutlet]", inputs: ["ngTemplateOutletContext", "ngTemplateOutlet", "ngTemplateOutletInjector"] }, { kind: "ngmodule", type: RouterModule }, { kind: "directive", type: i2.RouterLink, selector: "[routerLink]", inputs: ["target", "queryParams", "fragment", "queryParamsHandling", "state", "info", "relativeTo", "preserveFragment", "skipLocationChange", "replaceUrl", "routerLink"] }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaNavbarComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ksaa-navbar', standalone: true, imports: [CommonModule, RouterModule, NavbarTemplateDirective], template: `
    <nav
      class="ksaa-navbar"
      [ngClass]="{
        'ksaa-navbar--outlined': outlined,
        'ksaa-navbar--dense': dense,
        'ksaa-navbar--muted': muted,
        'ksaa-navbar--menu-open': menuOpen
      }"
      [attr.dir]="dir"
      role="navigation"
      [attr.aria-label]="ariaLabel || 'شريط التصفح'"
    >
      <div class="container">
        <div class="ksaa-navbar__section ksaa-navbar__section--start">
          <ng-container
            *ngIf="resolvedStartTemplate"
            [ngTemplateOutlet]="resolvedStartTemplate"
          ></ng-container>

          <button *ngIf="backLabel" class="ksaa-navbar__back" type="button">
            <span class="ksaa-navbar__back-icon" aria-hidden="true">←</span>
            <span class="ksaa-navbar__back-label">{{ backLabel }}</span>
          </button>

          <div *ngIf="brandLogoSrc || brandLabel" class="ksaa-navbar__brand">
            <img
              *ngIf="brandLogoSrc"
              class="ksaa-navbar__logo"
              [src]="brandLogoSrc"
              [alt]="brandLabel"
              loading="lazy"
            />
            <span *ngIf="brandLabel" class="ksaa-navbar__brand-text">{{ brandLabel }}</span>
          </div>

          <button
            class="ksaa-navbar__menu"
            type="button"
            aria-label="تبديل القائمة"
            (click)="toggleMenu()"
            [attr.aria-expanded]="menuOpen"
          >
            <span class="ksaa-navbar__menu-icon" aria-hidden="true">{{
              menuOpen ? '✕' : '☰'
            }}</span>
          </button>
        </div>

        <div class="ksaa-navbar__panel" [ngClass]="{ 'ksaa-navbar__panel--open': menuOpen }">
          <ul *ngIf="links?.length" class="ksaa-navbar__links" aria-label="التنقل الأساسي">
            <li
              *ngFor="let link of links; let i = index"
              class="ksaa-navbar__link"
              [ngClass]="{
                'ksaa-navbar__link--active': link.active,
                'ksaa-navbar__link--has-children': link.children?.length
              }"
            >
              <ng-container *ngIf="link.routePath; else navbarHref">
                <a
                  class="ksaa-navbar__link-content"
                  [routerLink]="link.routePath"
                  [attr.aria-haspopup]="link.children?.length ? 'true' : null"
                  (click)="handleLinkClick($event, link, i)"
                  [attr.aria-expanded]="link.children?.length ? isSubmenuOpen(i) : null"
                >
                  <span>{{ link.label }}</span>
                  <span *ngIf="link.children?.length" class="ksaa-navbar__caret" aria-hidden="true"
                    >▾</span
                  >
                </a>
              </ng-container>
              <ng-template #navbarHref>
                <a
                  class="ksaa-navbar__link-content"
                  [href]="link.href || '#'"
                  [attr.aria-haspopup]="link.children?.length ? 'true' : null"
                  (click)="handleLinkClick($event, link, i)"
                  [attr.aria-expanded]="link.children?.length ? isSubmenuOpen(i) : null"
                >
                  <span>{{ link.label }}</span>
                  <span *ngIf="link.children?.length" class="ksaa-navbar__caret" aria-hidden="true"
                    >▾</span
                  >
                </a>
              </ng-template>

              <ul
                *ngIf="link.children?.length"
                class="ksaa-navbar__submenu"
                aria-label="روابط فرعية"
                [ngClass]="{ 'ksaa-navbar__submenu--open': isSubmenuOpen(i) }"
              >
                <li *ngFor="let child of link.children" class="ksaa-navbar__submenu-item">
                  <ng-container *ngIf="child.routePath; else childHref">
                    <a class="ksaa-navbar__submenu-link" [routerLink]="child.routePath">
                      <span>{{ child.label }}</span>
                    </a>
                  </ng-container>
                  <ng-template #childHref>
                    <a class="ksaa-navbar__submenu-link" [href]="child.href || '#'">
                      <span>{{ child.label }}</span>
                    </a>
                  </ng-template>
                </li>
              </ul>
            </li>
          </ul>

          <div
            *ngIf="actions?.length || resolvedEndTemplate"
            class="ksaa-navbar__section ksaa-navbar__section--end"
          >
            <ng-container
              *ngIf="resolvedEndTemplate"
              [ngTemplateOutlet]="resolvedEndTemplate"
            ></ng-container>

            <button
              *ngFor="let action of actions"
              type="button"
              class="ksaa-navbar__action"
              [ngClass]="{
                'ksaa-navbar__action--primary': action.variant === 'primary',
                'ksaa-navbar__action--custom': action.variant === 'custom',
                'ksaa-navbar__action--outline': action.variant === 'outline'
              }"
            >
              <span *ngIf="action.icon" class="ksaa-navbar__action-icon" aria-hidden="true">{{
                action.icon
              }}</span>
              <span *ngIf="action.label">{{ action.label }}</span>
            </button>
          </div>
        </div>

        <button
          *ngIf="menuOpen"
          class="ksaa-navbar__overlay"
          type="button"
          aria-label="إغلاق القائمة"
          (click)="closeMenu()"
        ></button>
      </div>
    </nav>
  `, changeDetection: ChangeDetectionStrategy.OnPush, styles: [":host{display:block;width:100%}.ksaa-navbar .container{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:nowrap;padding:12px 0;background:var(--color-white);color:var(--color-gray-900);font-family:IBM Plex Sans Arabic,Arial,sans-serif;position:relative;margin:0 auto}.ksaa-navbar:not(.ksaa-navbar--outlined){border-bottom:1px solid var(--color-gray-200)}.ksaa-navbar--outlined{border:1px solid var(--color-gray-200);box-shadow:0 1px 0 0 var(--color-gray-200);border-radius:10px}.ksaa-navbar--muted{background:var(--color-gray-50)}.ksaa-navbar--dense{padding:8px 18px}.ksaa-navbar__section{display:inline-flex;align-items:center;gap:12px;min-width:0}.ksaa-navbar__section--start{flex:1;max-width:150px}.ksaa-navbar__section--end{justify-content:flex-end;flex:1;max-width:220px}.ksaa-navbar__brand{display:inline-flex;align-items:center;gap:10px;min-width:0}.ksaa-navbar__logo{width:120px;object-fit:contain}.ksaa-navbar__brand-text{font-weight:600;font-size:16px;color:var(--color-gray-900);white-space:nowrap}.ksaa-navbar__menu{display:none;align-items:center;justify-content:center;width:40px;height:40px;border-radius:10px;border:1px solid var(--color-gray-200);background:var(--color-white);color:var(--color-gray-900);cursor:pointer;transition:background .12s ease,color .12s ease}.ksaa-navbar__menu:hover,.ksaa-navbar__menu:focus-visible{background:var(--color-gray-100);outline:none}.ksaa-navbar__menu-icon{font-size:18px;line-height:1}.ksaa-navbar__links{list-style:none;display:inline-flex;align-items:center;gap:20px;margin:0;padding:0;flex-wrap:wrap;justify-content:flex-start;flex:0 1 auto}.ksaa-navbar__link{display:inline-flex;align-items:center;position:relative}.ksaa-navbar__link-content{display:inline-flex;align-items:center;gap:6px;color:var(--color-gray-600);font-weight:600;text-decoration:none;font-size:14px;padding:6px 4px;border-radius:8px;transition:color .12s ease,background .12s ease}.ksaa-navbar__link-content:hover,.ksaa-navbar__link-content:focus-visible{color:var(--color-slate-900);background:var(--color-gray-100);outline:none}.ksaa-navbar__link--active .ksaa-navbar__link-content{color:var(--color-primary-default)}.ksaa-navbar__caret{font-size:10px;transform:translateY(-1px)}.ksaa-navbar__submenu{display:none;position:absolute;inset-inline-start:0;top:calc(100% + 8px);min-width:200px;background:var(--color-white);border:1px solid var(--color-gray-200);box-shadow:0 10px 40px #0000000f;border-radius:10px;padding:10px 12px;flex-direction:column;gap:6px;z-index:2}.ksaa-navbar__submenu--open{display:flex}.ksaa-navbar__submenu-item{list-style:none}.ksaa-navbar__submenu-link{display:flex;align-items:center;gap:6px;color:var(--color-gray-900);text-decoration:none;font-size:14px;font-weight:600;padding:8px 10px;border-radius:8px;transition:background .12s ease,color .12s ease}.ksaa-navbar__submenu-link:hover,.ksaa-navbar__submenu-link:focus-visible{background:var(--color-gray-100);color:var(--color-slate-900);outline:none}.ksaa-navbar__back{display:inline-flex;align-items:center;gap:8px;background:transparent;border:1px solid var(--color-gray-200);border-radius:10px;padding:8px 12px;color:var(--color-primary-default);font-weight:700;cursor:pointer}.ksaa-navbar__back:hover,.ksaa-navbar__back:focus-visible{background:var(--color-success-light);outline:none}.ksaa-navbar__back-icon{font-size:14px;line-height:1}.ksaa-navbar__links+.ksaa-navbar__section--end,.ksaa-navbar__section--start+.ksaa-navbar__links{flex:1}.ksaa-navbar__panel{display:flex;align-items:center;justify-content:space-between;gap:16px;flex:1}.ksaa-navbar__panel--open{display:flex}.ksaa-navbar__section--end{display:inline-flex;align-items:center;gap:12px}.ksaa-navbar__action{border-radius:10px;padding:10px 16px;font-weight:700;font-size:14px;cursor:pointer;background:var(--color-white);border:1px solid var(--color-gray-200);color:var(--color-slate-900);transition:background .12s ease,color .12s ease,border-color .12s ease;display:inline-flex;align-items:center;gap:8px}.ksaa-navbar__action--primary{background:var(--color-primary-default);color:var(--color-white);border-color:var(--color-primary-default)}.ksaa-navbar__action--outline{background:var(--color-white);color:var(--color-primary-default);border-color:var(--color-primary-default)}.ksaa-navbar__action--custom{background:transparent;border-color:transparent;color:var(--color-primary-default)}.ksaa-navbar__action:hover,.ksaa-navbar__action:focus-visible{background:var(--color-success-light);outline:none}.ksaa-navbar__action--primary:hover,.ksaa-navbar__action--primary:focus-visible{background:var(--color-primary-sa-flag);color:var(--color-white)}.ksaa-navbar__action-icon{font-size:12px}@media(max-width:960px){.ksaa-navbar{flex-wrap:wrap;gap:10px}.ksaa-navbar__section--start,.ksaa-navbar__section--end{flex:1 1 100%;justify-content:space-between}.ksaa-navbar__links{flex:1 1 100%;justify-content:flex-start;gap:14px}.ksaa-navbar__panel{flex-wrap:wrap}}@media(max-width:640px){.ksaa-navbar{flex-direction:column;align-items:stretch;gap:12px;padding:12px 16px}.ksaa-navbar__section--start,.ksaa-navbar__section--end{flex:1 1 auto;width:100%}.ksaa-navbar__section--start{justify-content:space-between;max-width:100%}.ksaa-navbar__panel{flex-wrap:nowrap}.ksaa-navbar__section--end{justify-content:flex-start;flex-wrap:wrap;gap:8px}.ksaa-navbar__menu{display:inline-flex}.ksaa-navbar__panel{display:flex;position:fixed;inset-block:0;inset-inline-end:0;flex-direction:column;gap:12px;width:min(360px,90%);background:var(--color-white);border-inline-start:1px solid var(--color-gray-200);box-shadow:-12px 0 40px #0000001f;padding:20px 16px;z-index:3;transform:translate(calc(-100% + 24px));opacity:0;pointer-events:none;visibility:hidden;transition:transform .18s ease-in-out,box-shadow .18s ease-in-out,opacity .14s ease-in-out,visibility 0ms linear .18s;overflow-y:auto}.ksaa-navbar__panel--open{transform:translate(0);opacity:1;pointer-events:auto;visibility:visible;transition-delay:0ms}.ksaa-navbar__links{width:100%;flex-direction:column;align-items:stretch;gap:6px}.ksaa-navbar__link{width:100%;flex-wrap:wrap}.ksaa-navbar__link-content{width:100%;justify-content:space-between;white-space:normal;flex-wrap:wrap;border:1px solid var(--color-gray-200);border-radius:10px;padding:12px 14px}.ksaa-navbar__link-content[aria-expanded=true] .ksaa-navbar__caret{transform:rotate(180deg)}.ksaa-navbar__submenu{position:static;width:100%;display:flex;flex-direction:column;gap:8px;padding:0 10px;border:1px solid var(--color-gray-200);box-shadow:none;background:var(--color-slate-50);border-radius:12px;max-height:0;overflow:hidden;opacity:0;visibility:hidden;transform:translateY(-6px);transition:max-height .2s ease,opacity .16s ease,visibility 0ms linear .2s,transform .18s ease,padding .16s ease}.ksaa-navbar__submenu--open{max-height:560px;padding:8px 10px 10px;opacity:1;visibility:visible;transform:translateY(0);transition-delay:0ms}.ksaa-navbar__submenu-item+.ksaa-navbar__submenu-item{border-top:1px solid var(--color-gray-200);padding-top:8px;margin-top:4px}.ksaa-navbar__submenu-link{width:100%;flex-wrap:wrap;padding:8px 10px;background:transparent;border:none;color:var(--color-slate-900);font-weight:600;border-radius:10px}.ksaa-navbar__action{width:100%;justify-content:center}.ksaa-navbar__overlay{display:block;position:fixed;inset:0;background:#00000059;border:none;padding:0;margin:0;cursor:pointer;z-index:2}}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { backLabel: [{
                type: Input
            }], brandLogoSrc: [{
                type: Input
            }], brandLabel: [{
                type: Input
            }], links: [{
                type: Input
            }], actions: [{
                type: Input
            }], startTemplate: [{
                type: Input
            }], endTemplate: [{
                type: Input
            }], muted: [{
                type: Input
            }], dense: [{
                type: Input
            }], outlined: [{
                type: Input
            }], dir: [{
                type: Input
            }], ariaLabel: [{
                type: Input
            }], contentStartTemplate: [{
                type: ContentChild,
                args: ['startTemplate', { read: TemplateRef }]
            }], contentEndTemplate: [{
                type: ContentChild,
                args: ['endTemplate', { read: TemplateRef }]
            }], projectedTemplates: [{
                type: ContentChildren,
                args: [NavbarTemplateDirective]
            }], projectedContentTemplates: [{
                type: ContentChildren,
                args: [TemplateRef]
            }], handleDocumentClick: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

class KsaaCardComponent {
    projectedNodes;
    hasProjectedContent = false;
    /** Title displayed at the top of the card */
    title;
    /** Supporting description text */
    description;
    /** Small muted line at the bottom for contextual hints */
    note;
    /** Small label rendered next to the title */
    metaLabel;
    /** Optional icon displayed in the header */
    cardIconSrc;
    /** Enable selection affordance */
    selectable = false;
    /** Whether the card is currently selected */
    selected = false;
    /** Visual subdued background */
    muted = false;
    /** Disable interactions and apply disabled styling */
    disabled = false;
    /** Optional click handler */
    onClick = new EventEmitter();
    ngAfterContentInit() {
        this.updateProjectedContent();
        this.projectedNodes.changes.subscribe(() => this.updateProjectedContent());
    }
    handleClick(event) {
        if (this.disabled) {
            event.preventDefault();
            return;
        }
        this.onClick.emit(event);
    }
    updateProjectedContent() {
        this.hasProjectedContent = this.projectedNodes?.length > 0;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaCardComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.3", type: KsaaCardComponent, isStandalone: true, selector: "ksaa-card", inputs: { title: "title", description: "description", note: "note", metaLabel: "metaLabel", cardIconSrc: "cardIconSrc", selectable: "selectable", selected: "selected", muted: "muted", disabled: "disabled" }, outputs: { onClick: "onClick" }, queries: [{ propertyName: "projectedNodes", predicate: ["*"], descendants: true, read: ElementRef }], ngImport: i0, template: `
    <article
      class="ksaa-card"
      [ngClass]="{
        'ksaa-card--selected': selected,
        'ksaa-card--muted': muted,
        'ksaa-card--disabled': disabled
      }"
      [attr.aria-selected]="selectable ? selected : null"
      [attr.aria-disabled]="disabled"
      dir="rtl"
      (click)="handleClick($event)"
    >
      <div class="ksaa-card__row">
        <div *ngIf="selectable" class="ksaa-card__leading" aria-hidden="true">
          <span class="ksaa-card__selector">
            <span *ngIf="selected" class="ksaa-card__selector-icon">✓</span>
          </span>
        </div>

        <div class="ksaa-card__content">
          <ng-content></ng-content>

          <ng-container *ngIf="!hasProjectedContent">
            <header class="ksaa-card__header">
              <img
                *ngIf="cardIconSrc"
                class="ksaa-card__icon"
                [src]="cardIconSrc"
                alt=""
                loading="lazy"
              />
              <div class="ksaa-card__title-group">
                <p class="ksaa-card__title">{{ title }}</p>
                <span *ngIf="metaLabel" class="ksaa-card__meta">{{ metaLabel }}</span>
              </div>
            </header>

            <p *ngIf="description" class="ksaa-card__description">{{ description }}</p>
            <p *ngIf="note" class="ksaa-card__note">{{ note }}</p>
          </ng-container>
        </div>
      </div>
    </article>
  `, isInline: true, styles: [":host{display:block}.ksaa-card{border:1px solid var(--color-gray-200);border-radius:16px;background:var(--color-white);padding:16px;color:var(--color-gray-900);font-family:var(--font-family-ibm-plex-sans-arabic);transition:border-color .12s ease,box-shadow .12s ease;width:100%;box-shadow:0 1px 3px 0 var(--color-gray-200)}.ksaa-card:focus-visible{outline:2px solid var(--color-primary-default);outline-offset:3px}.ksaa-card--muted{background:var(--color-gray-100)}.ksaa-card--selected{border-color:var(--color-primary-default);box-shadow:0 0 0 1px var(--color-primary-default) inset}.ksaa-card--disabled{color:var(--color-gray-400);border-color:var(--color-gray-200);box-shadow:none;cursor:not-allowed}.ksaa-card__row{display:flex;gap:12px;align-items:flex-start}.ksaa-card__leading{padding-top:2px}.ksaa-card__selector{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:8px;border:1px solid var(--color-gray-300);background:var(--color-white);color:var(--color-primary-default);font-size:13px;font-weight:600}.ksaa-card--selected .ksaa-card__selector{background:var(--color-primary-default);border-color:var(--color-primary-default);color:var(--color-white)}.ksaa-card__content{display:flex;flex-direction:column;gap:6px;flex:1}.ksaa-card__header{display:flex;align-items:start;justify-content:space-between;gap:12px;flex-direction:column}.ksaa-card__title-group{display:flex;align-items:center;gap:8px}.ksaa-card__title{margin:0;font-size:16px;font-weight:700;line-height:1.4}.ksaa-card__meta{display:inline-flex;align-items:center;justify-content:center;padding:2px 8px;border-radius:10px;background:var(--color-success-light);color:var(--color-primary-default);font-size:12px;font-weight:700}.ksaa-card__icon{width:26px;height:26px;border-radius:50%;border:1px solid var(--color-primary-default);padding:3px;object-fit:contain;background:var(--color-success-light);box-shadow:0 0 0 1px var(--color-success-light) inset}.ksaa-card__description{margin:0;color:var(--color-gray-600);font-size:14px;line-height:1.5}.ksaa-card__note{margin:0;color:var(--color-gray-500);font-size:13px;line-height:1.4}.ksaa-card--disabled .ksaa-card__selector,.ksaa-card--disabled .ksaa-card__icon,.ksaa-card--disabled .ksaa-card__meta{border-color:var(--color-gray-200);color:var(--color-gray-400);background:var(--color-gray-50)}.ksaa-card--disabled .ksaa-card__meta{color:var(--color-gray-400);background:var(--color-gray-100)}.ksaa-card--disabled .ksaa-card__icon{filter:grayscale(1)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaCardComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ksaa-card', standalone: true, imports: [CommonModule], template: `
    <article
      class="ksaa-card"
      [ngClass]="{
        'ksaa-card--selected': selected,
        'ksaa-card--muted': muted,
        'ksaa-card--disabled': disabled
      }"
      [attr.aria-selected]="selectable ? selected : null"
      [attr.aria-disabled]="disabled"
      dir="rtl"
      (click)="handleClick($event)"
    >
      <div class="ksaa-card__row">
        <div *ngIf="selectable" class="ksaa-card__leading" aria-hidden="true">
          <span class="ksaa-card__selector">
            <span *ngIf="selected" class="ksaa-card__selector-icon">✓</span>
          </span>
        </div>

        <div class="ksaa-card__content">
          <ng-content></ng-content>

          <ng-container *ngIf="!hasProjectedContent">
            <header class="ksaa-card__header">
              <img
                *ngIf="cardIconSrc"
                class="ksaa-card__icon"
                [src]="cardIconSrc"
                alt=""
                loading="lazy"
              />
              <div class="ksaa-card__title-group">
                <p class="ksaa-card__title">{{ title }}</p>
                <span *ngIf="metaLabel" class="ksaa-card__meta">{{ metaLabel }}</span>
              </div>
            </header>

            <p *ngIf="description" class="ksaa-card__description">{{ description }}</p>
            <p *ngIf="note" class="ksaa-card__note">{{ note }}</p>
          </ng-container>
        </div>
      </div>
    </article>
  `, styles: [":host{display:block}.ksaa-card{border:1px solid var(--color-gray-200);border-radius:16px;background:var(--color-white);padding:16px;color:var(--color-gray-900);font-family:var(--font-family-ibm-plex-sans-arabic);transition:border-color .12s ease,box-shadow .12s ease;width:100%;box-shadow:0 1px 3px 0 var(--color-gray-200)}.ksaa-card:focus-visible{outline:2px solid var(--color-primary-default);outline-offset:3px}.ksaa-card--muted{background:var(--color-gray-100)}.ksaa-card--selected{border-color:var(--color-primary-default);box-shadow:0 0 0 1px var(--color-primary-default) inset}.ksaa-card--disabled{color:var(--color-gray-400);border-color:var(--color-gray-200);box-shadow:none;cursor:not-allowed}.ksaa-card__row{display:flex;gap:12px;align-items:flex-start}.ksaa-card__leading{padding-top:2px}.ksaa-card__selector{display:inline-flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:8px;border:1px solid var(--color-gray-300);background:var(--color-white);color:var(--color-primary-default);font-size:13px;font-weight:600}.ksaa-card--selected .ksaa-card__selector{background:var(--color-primary-default);border-color:var(--color-primary-default);color:var(--color-white)}.ksaa-card__content{display:flex;flex-direction:column;gap:6px;flex:1}.ksaa-card__header{display:flex;align-items:start;justify-content:space-between;gap:12px;flex-direction:column}.ksaa-card__title-group{display:flex;align-items:center;gap:8px}.ksaa-card__title{margin:0;font-size:16px;font-weight:700;line-height:1.4}.ksaa-card__meta{display:inline-flex;align-items:center;justify-content:center;padding:2px 8px;border-radius:10px;background:var(--color-success-light);color:var(--color-primary-default);font-size:12px;font-weight:700}.ksaa-card__icon{width:26px;height:26px;border-radius:50%;border:1px solid var(--color-primary-default);padding:3px;object-fit:contain;background:var(--color-success-light);box-shadow:0 0 0 1px var(--color-success-light) inset}.ksaa-card__description{margin:0;color:var(--color-gray-600);font-size:14px;line-height:1.5}.ksaa-card__note{margin:0;color:var(--color-gray-500);font-size:13px;line-height:1.4}.ksaa-card--disabled .ksaa-card__selector,.ksaa-card--disabled .ksaa-card__icon,.ksaa-card--disabled .ksaa-card__meta{border-color:var(--color-gray-200);color:var(--color-gray-400);background:var(--color-gray-50)}.ksaa-card--disabled .ksaa-card__meta{color:var(--color-gray-400);background:var(--color-gray-100)}.ksaa-card--disabled .ksaa-card__icon{filter:grayscale(1)}\n"] }]
        }], propDecorators: { projectedNodes: [{
                type: ContentChildren,
                args: ['*', { descendants: true, read: ElementRef }]
            }], title: [{
                type: Input
            }], description: [{
                type: Input
            }], note: [{
                type: Input
            }], metaLabel: [{
                type: Input
            }], cardIconSrc: [{
                type: Input
            }], selectable: [{
                type: Input
            }], selected: [{
                type: Input
            }], muted: [{
                type: Input
            }], disabled: [{
                type: Input
            }], onClick: [{
                type: Output
            }] } });

class KsaaCheckboxComponent {
    inputRef;
    /** Checkbox label text */
    label;
    /** Supporting description below the label */
    description;
    /** Error or warning text displayed below */
    errorMessage;
    /** Whether the checkbox is checked */
    checked = false;
    /** Whether the checkbox is in the indeterminate state */
    indeterminate = false;
    /** Disable interactions */
    disabled = false;
    /** Visual size of the checkbox */
    size = 'medium';
    /** Color treatment for the checkbox */
    variant = 'primary';
    /** Emits when the checked state changes */
    checkedChange = new EventEmitter();
    /** Emits the native change event */
    onChange = new EventEmitter();
    onChangeFn = () => { };
    onTouchedFn = () => { };
    ngAfterViewInit() {
        this.updateIndeterminate();
    }
    ngOnChanges() {
        this.updateIndeterminate();
    }
    handleChange(event) {
        const target = event.target;
        this.checked = target.checked;
        this.onChange.emit(event);
        this.checkedChange.emit(target.checked);
        this.onChangeFn(target.checked);
    }
    writeValue(value) {
        this.checked = value;
    }
    registerOnChange(fn) {
        this.onChangeFn = fn;
    }
    registerOnTouched(fn) {
        this.onTouchedFn = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    markTouched() {
        this.onTouchedFn();
    }
    updateIndeterminate() {
        if (!this.inputRef) {
            return;
        }
        this.inputRef.nativeElement.indeterminate = this.indeterminate;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaCheckboxComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.3", type: KsaaCheckboxComponent, isStandalone: true, selector: "ksaa-checkbox", inputs: { label: "label", description: "description", errorMessage: "errorMessage", checked: "checked", indeterminate: "indeterminate", disabled: "disabled", size: "size", variant: "variant" }, outputs: { checkedChange: "checkedChange", onChange: "onChange" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => KsaaCheckboxComponent),
                multi: true,
            },
        ], viewQueries: [{ propertyName: "inputRef", first: true, predicate: ["inputRef"], descendants: true }], usesOnChanges: true, ngImport: i0, template: `
    <label
      class="ksaa-checkbox"
      [ngClass]="[
        'ksaa-checkbox--' + size,
        'ksaa-checkbox--' + variant,
        checked ? 'ksaa-checkbox--checked' : '',
        indeterminate ? 'ksaa-checkbox--indeterminate' : '',
        disabled ? 'ksaa-checkbox--disabled' : '',
        errorMessage ? 'ksaa-checkbox--error' : ''
      ]"
    >
      <input
        #inputRef
        class="ksaa-checkbox__input"
        type="checkbox"
        [checked]="checked"
        [disabled]="disabled"
        [attr.aria-invalid]="errorMessage ? 'true' : null"
        (change)="handleChange($event)"
        (blur)="markTouched()"
      />
      <span class="ksaa-checkbox__control" aria-hidden="true">
        <span class="ksaa-checkbox__icon" *ngIf="checked || indeterminate">
          {{ indeterminate ? '–' : '✓' }}
        </span>
      </span>
      <span class="ksaa-checkbox__content" *ngIf="label || description || errorMessage">
        <span *ngIf="label" class="ksaa-checkbox__label">{{ label }}</span>
        <span *ngIf="description" class="ksaa-checkbox__description">{{ description }}</span>
        <span *ngIf="errorMessage" class="ksaa-checkbox__error">
          <span class="ksaa-checkbox__error-icon" aria-hidden="true">!</span>
          <span>{{ errorMessage }}</span>
        </span>
      </span>
    </label>
  `, isInline: true, styles: [":host{display:inline-block;font-family:var(--font-family-ibm-plex-sans-arabic)}.ksaa-checkbox{--checkbox-active: var(--color-primary-default);--checkbox-active-hover: var(--color-primary-sa-flag);display:inline-flex;align-items:flex-start;gap:12px;cursor:pointer;color:var(--color-gray-900)}.ksaa-checkbox--neutral{--checkbox-active: var(--color-gray-900);--checkbox-active-hover: var(--color-slate-900)}.ksaa-checkbox--disabled{cursor:not-allowed;opacity:.6}.ksaa-checkbox__input{position:absolute;opacity:0;width:1px;height:1px;overflow:hidden;pointer-events:none}.ksaa-checkbox__control{display:inline-flex;align-items:center;justify-content:center;border:1px solid var(--color-gray-400);border-radius:var(--radius-sm);background:var(--color-white);color:#fff;transition:background-color .14s ease,border-color .14s ease,box-shadow .14s ease;box-shadow:0 1px 2px #0f172a0d}.ksaa-checkbox__icon{font-size:12px;font-weight:700;line-height:1}.ksaa-checkbox--small .ksaa-checkbox__control{width:16px;height:16px}.ksaa-checkbox--medium .ksaa-checkbox__control{width:20px;height:20px}.ksaa-checkbox--large .ksaa-checkbox__control{width:24px;height:24px}.ksaa-checkbox--small .ksaa-checkbox__icon{font-size:10px}.ksaa-checkbox--large .ksaa-checkbox__icon{font-size:14px}.ksaa-checkbox--checked .ksaa-checkbox__control,.ksaa-checkbox--indeterminate .ksaa-checkbox__control{background:var(--checkbox-active);border-color:var(--checkbox-active);color:#fff}.ksaa-checkbox:not(.ksaa-checkbox--disabled):hover .ksaa-checkbox__control{border-color:var(--checkbox-active-hover);box-shadow:0 0 0 2px var(--color-primary-100)}.ksaa-checkbox__input:focus-visible+.ksaa-checkbox__control{outline:2px solid var(--checkbox-active);outline-offset:2px}.ksaa-checkbox__content{display:flex;flex-direction:column;gap:4px}.ksaa-checkbox__label{font-size:var(--text-sm-medium-font-size);font-weight:var(--text-sm-semibold-font-weight)}.ksaa-checkbox__description{font-size:var(--text-xs-medium-font-size);color:var(--color-gray-600);line-height:1.4}.ksaa-checkbox__error{display:inline-flex;align-items:center;gap:6px;font-size:var(--text-xs-medium-font-size);color:var(--color-error-default);font-weight:var(--text-sm-semibold-font-weight)}.ksaa-checkbox__error-icon{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;background:var(--color-error-light);color:var(--color-error-default);border:1px solid var(--color-error-default);font-size:11px;font-weight:700}.ksaa-checkbox--error .ksaa-checkbox__control{border-color:var(--color-error-default)}.ksaa-checkbox--error.ksaa-checkbox--checked .ksaa-checkbox__control,.ksaa-checkbox--error.ksaa-checkbox--indeterminate .ksaa-checkbox__control{background:var(--color-error-default);border-color:var(--color-error-default)}.ksaa-checkbox--disabled .ksaa-checkbox__control{background:var(--color-gray-50);border-color:var(--color-gray-200);color:var(--color-gray-300);box-shadow:none}.ksaa-checkbox--disabled .ksaa-checkbox__label,.ksaa-checkbox--disabled .ksaa-checkbox__description{color:var(--color-gray-400)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaCheckboxComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ksaa-checkbox', standalone: true, imports: [CommonModule], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => KsaaCheckboxComponent),
                            multi: true,
                        },
                    ], template: `
    <label
      class="ksaa-checkbox"
      [ngClass]="[
        'ksaa-checkbox--' + size,
        'ksaa-checkbox--' + variant,
        checked ? 'ksaa-checkbox--checked' : '',
        indeterminate ? 'ksaa-checkbox--indeterminate' : '',
        disabled ? 'ksaa-checkbox--disabled' : '',
        errorMessage ? 'ksaa-checkbox--error' : ''
      ]"
    >
      <input
        #inputRef
        class="ksaa-checkbox__input"
        type="checkbox"
        [checked]="checked"
        [disabled]="disabled"
        [attr.aria-invalid]="errorMessage ? 'true' : null"
        (change)="handleChange($event)"
        (blur)="markTouched()"
      />
      <span class="ksaa-checkbox__control" aria-hidden="true">
        <span class="ksaa-checkbox__icon" *ngIf="checked || indeterminate">
          {{ indeterminate ? '–' : '✓' }}
        </span>
      </span>
      <span class="ksaa-checkbox__content" *ngIf="label || description || errorMessage">
        <span *ngIf="label" class="ksaa-checkbox__label">{{ label }}</span>
        <span *ngIf="description" class="ksaa-checkbox__description">{{ description }}</span>
        <span *ngIf="errorMessage" class="ksaa-checkbox__error">
          <span class="ksaa-checkbox__error-icon" aria-hidden="true">!</span>
          <span>{{ errorMessage }}</span>
        </span>
      </span>
    </label>
  `, styles: [":host{display:inline-block;font-family:var(--font-family-ibm-plex-sans-arabic)}.ksaa-checkbox{--checkbox-active: var(--color-primary-default);--checkbox-active-hover: var(--color-primary-sa-flag);display:inline-flex;align-items:flex-start;gap:12px;cursor:pointer;color:var(--color-gray-900)}.ksaa-checkbox--neutral{--checkbox-active: var(--color-gray-900);--checkbox-active-hover: var(--color-slate-900)}.ksaa-checkbox--disabled{cursor:not-allowed;opacity:.6}.ksaa-checkbox__input{position:absolute;opacity:0;width:1px;height:1px;overflow:hidden;pointer-events:none}.ksaa-checkbox__control{display:inline-flex;align-items:center;justify-content:center;border:1px solid var(--color-gray-400);border-radius:var(--radius-sm);background:var(--color-white);color:#fff;transition:background-color .14s ease,border-color .14s ease,box-shadow .14s ease;box-shadow:0 1px 2px #0f172a0d}.ksaa-checkbox__icon{font-size:12px;font-weight:700;line-height:1}.ksaa-checkbox--small .ksaa-checkbox__control{width:16px;height:16px}.ksaa-checkbox--medium .ksaa-checkbox__control{width:20px;height:20px}.ksaa-checkbox--large .ksaa-checkbox__control{width:24px;height:24px}.ksaa-checkbox--small .ksaa-checkbox__icon{font-size:10px}.ksaa-checkbox--large .ksaa-checkbox__icon{font-size:14px}.ksaa-checkbox--checked .ksaa-checkbox__control,.ksaa-checkbox--indeterminate .ksaa-checkbox__control{background:var(--checkbox-active);border-color:var(--checkbox-active);color:#fff}.ksaa-checkbox:not(.ksaa-checkbox--disabled):hover .ksaa-checkbox__control{border-color:var(--checkbox-active-hover);box-shadow:0 0 0 2px var(--color-primary-100)}.ksaa-checkbox__input:focus-visible+.ksaa-checkbox__control{outline:2px solid var(--checkbox-active);outline-offset:2px}.ksaa-checkbox__content{display:flex;flex-direction:column;gap:4px}.ksaa-checkbox__label{font-size:var(--text-sm-medium-font-size);font-weight:var(--text-sm-semibold-font-weight)}.ksaa-checkbox__description{font-size:var(--text-xs-medium-font-size);color:var(--color-gray-600);line-height:1.4}.ksaa-checkbox__error{display:inline-flex;align-items:center;gap:6px;font-size:var(--text-xs-medium-font-size);color:var(--color-error-default);font-weight:var(--text-sm-semibold-font-weight)}.ksaa-checkbox__error-icon{display:inline-flex;align-items:center;justify-content:center;width:16px;height:16px;border-radius:50%;background:var(--color-error-light);color:var(--color-error-default);border:1px solid var(--color-error-default);font-size:11px;font-weight:700}.ksaa-checkbox--error .ksaa-checkbox__control{border-color:var(--color-error-default)}.ksaa-checkbox--error.ksaa-checkbox--checked .ksaa-checkbox__control,.ksaa-checkbox--error.ksaa-checkbox--indeterminate .ksaa-checkbox__control{background:var(--color-error-default);border-color:var(--color-error-default)}.ksaa-checkbox--disabled .ksaa-checkbox__control{background:var(--color-gray-50);border-color:var(--color-gray-200);color:var(--color-gray-300);box-shadow:none}.ksaa-checkbox--disabled .ksaa-checkbox__label,.ksaa-checkbox--disabled .ksaa-checkbox__description{color:var(--color-gray-400)}\n"] }]
        }], propDecorators: { inputRef: [{
                type: ViewChild,
                args: ['inputRef']
            }], label: [{
                type: Input
            }], description: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], checked: [{
                type: Input
            }], indeterminate: [{
                type: Input
            }], disabled: [{
                type: Input
            }], size: [{
                type: Input
            }], variant: [{
                type: Input
            }], checkedChange: [{
                type: Output
            }], onChange: [{
                type: Output
            }] } });

class KsaaTextareaComponent {
    /** Field label */
    label = 'Label';
    /** Textarea value */
    value = '';
    /** Placeholder text */
    placeholder = 'Entered text';
    /** Helper text below the textarea */
    helperText = '';
    /** Error message displayed below the textarea */
    errorMessage = '';
    /** Textarea name attribute */
    name;
    /** Textarea id attribute */
    inputId;
    /** Direction of the text flow */
    dir = 'ltr';
    /** Visual size of the textarea */
    size = 'medium';
    /** Force a visual state for Storybook */
    state = 'default';
    /** Disable interactions */
    disabled = false;
    /** Mark the textarea as read-only */
    readonly = false;
    /** Shows a required indicator */
    required = false;
    /** Number of visible text lines */
    rows = 3;
    /** Emits the current value */
    valueChange = new EventEmitter();
    /** Emits the native input event */
    onInput = new EventEmitter();
    /** Emits the native blur event */
    onBlur = new EventEmitter();
    isFocused = false;
    onChangeFn = () => { };
    onTouchedFn = () => { };
    get describedById() {
        if (this.errorMessage) {
            return this.inputId ? `${this.inputId}-error` : null;
        }
        if (this.helperText) {
            return this.inputId ? `${this.inputId}-helper` : null;
        }
        return null;
    }
    handleInput(event) {
        const target = event.target;
        this.value = target.value;
        this.valueChange.emit(this.value);
        this.onInput.emit(event);
        this.onChangeFn(this.value);
    }
    handleFocus() {
        this.isFocused = true;
    }
    handleBlur(event) {
        this.isFocused = false;
        this.onTouchedFn();
        this.onBlur.emit(event);
    }
    writeValue(value) {
        this.value = value ?? '';
    }
    registerOnChange(fn) {
        this.onChangeFn = fn;
    }
    registerOnTouched(fn) {
        this.onTouchedFn = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaTextareaComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.3", type: KsaaTextareaComponent, isStandalone: true, selector: "ksaa-textarea", inputs: { label: "label", value: "value", placeholder: "placeholder", helperText: "helperText", errorMessage: "errorMessage", name: "name", inputId: "inputId", dir: "dir", size: "size", state: "state", disabled: "disabled", readonly: "readonly", required: "required", rows: "rows" }, outputs: { valueChange: "valueChange", onInput: "onInput", onBlur: "onBlur" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => KsaaTextareaComponent),
                multi: true,
            },
        ], ngImport: i0, template: `
    <label
      class="ksaa-textarea"
      [ngClass]="[
        'ksaa-textarea--' + size,
        errorMessage ? 'ksaa-textarea--error' : '',
        disabled ? 'ksaa-textarea--disabled' : '',
        readonly ? 'ksaa-textarea--readonly' : '',
        state === 'hover' ? 'ksaa-textarea--hover' : '',
        state === 'focus' || isFocused ? 'ksaa-textarea--focused' : ''
      ]"
      [attr.dir]="dir"
    >
      <span class="ksaa-textarea__label" *ngIf="label">
        {{ label }}
        <span *ngIf="required" class="ksaa-textarea__required" aria-hidden="true">*</span>
      </span>
      <div class="ksaa-textarea__field">
        <textarea
          class="ksaa-textarea__control"
          [attr.placeholder]="placeholder"
          [attr.name]="name"
          [attr.id]="inputId"
          [attr.rows]="rows"
          [attr.aria-invalid]="errorMessage ? 'true' : null"
          [attr.aria-describedby]="describedById"
          [disabled]="disabled"
          [readonly]="readonly"
          [value]="value"
          (input)="handleInput($event)"
          (focus)="handleFocus()"
          (blur)="handleBlur($event)"
        ></textarea>
      </div>
      <span
        *ngIf="helperText && !errorMessage"
        class="ksaa-textarea__helper"
        [attr.id]="inputId ? inputId + '-helper' : null"
      >{{ helperText }}</span>
      <span
        *ngIf="errorMessage"
        class="ksaa-textarea__error"
        [attr.id]="inputId ? inputId + '-error' : null"
      >{{ errorMessage }}</span>
    </label>
  `, isInline: true, styles: [":host{display:inline-block;font-family:var(--font-family-ibm-plex-sans-arabic)}.ksaa-textarea{display:flex;flex-direction:column;gap:4px;color:var(--color-gray-900)}.ksaa-textarea__label{font-size:var(--text-sm-medium-font-size);font-weight:var(--text-sm-semibold-font-weight)}.ksaa-textarea__required{color:var(--color-error-default);margin-inline-start:2px}.ksaa-textarea__field{position:relative;display:flex}.ksaa-textarea__control{width:100%;border:1px solid var(--color-gray-300);border-radius:var(--radius-sm);background:var(--color-white);color:var(--color-gray-900);font-size:var(--text-sm-medium-font-size);line-height:1.4;transition:border-color .14s ease,box-shadow .14s ease,background-color .14s ease;box-shadow:0 1px 2px #0f172a0d;padding:10px 12px;resize:vertical;min-height:96px}.ksaa-textarea__control::placeholder{color:var(--color-gray-400)}.ksaa-textarea__control:focus-visible{outline:none}.ksaa-textarea:not(.ksaa-textarea--disabled):not(.ksaa-textarea--readonly) .ksaa-textarea__control:hover,.ksaa-textarea--hover .ksaa-textarea__control{border-color:var(--color-field-border-hover)}.ksaa-textarea--focused .ksaa-textarea__control,.ksaa-textarea__control:focus-visible{border-color:var(--color-field-border-hover);box-shadow:0 1px 1px 0 var(--color-default)}.ksaa-textarea__helper{font-size:var(--text-xs-medium-font-size);color:var(--color-gray-600)}.ksaa-textarea__error{font-size:var(--text-xs-medium-font-size);color:var(--color-error-default);font-weight:var(--text-sm-semibold-font-weight)}.ksaa-textarea--error .ksaa-textarea__control{border-color:var(--color-error-default);box-shadow:0 0 0 2px #b4231829}.ksaa-textarea--disabled{opacity:.6;cursor:not-allowed}.ksaa-textarea--disabled .ksaa-textarea__control{background:var(--color-gray-50);border-color:var(--color-gray-200);color:var(--color-gray-400);box-shadow:none}.ksaa-textarea--disabled .ksaa-textarea__label,.ksaa-textarea--disabled .ksaa-textarea__helper{color:var(--color-gray-400)}.ksaa-textarea--readonly .ksaa-textarea__control{background:var(--color-gray-100);border-color:var(--color-gray-200);color:var(--color-gray-700)}.ksaa-textarea--small .ksaa-textarea__control{padding:6px 10px;font-size:var(--text-xs-medium-font-size);min-height:72px}.ksaa-textarea--large .ksaa-textarea__control{padding:12px 14px;font-size:var(--text-md-medium-font-size);min-height:120px}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaTextareaComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ksaa-textarea', standalone: true, imports: [CommonModule], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => KsaaTextareaComponent),
                            multi: true,
                        },
                    ], template: `
    <label
      class="ksaa-textarea"
      [ngClass]="[
        'ksaa-textarea--' + size,
        errorMessage ? 'ksaa-textarea--error' : '',
        disabled ? 'ksaa-textarea--disabled' : '',
        readonly ? 'ksaa-textarea--readonly' : '',
        state === 'hover' ? 'ksaa-textarea--hover' : '',
        state === 'focus' || isFocused ? 'ksaa-textarea--focused' : ''
      ]"
      [attr.dir]="dir"
    >
      <span class="ksaa-textarea__label" *ngIf="label">
        {{ label }}
        <span *ngIf="required" class="ksaa-textarea__required" aria-hidden="true">*</span>
      </span>
      <div class="ksaa-textarea__field">
        <textarea
          class="ksaa-textarea__control"
          [attr.placeholder]="placeholder"
          [attr.name]="name"
          [attr.id]="inputId"
          [attr.rows]="rows"
          [attr.aria-invalid]="errorMessage ? 'true' : null"
          [attr.aria-describedby]="describedById"
          [disabled]="disabled"
          [readonly]="readonly"
          [value]="value"
          (input)="handleInput($event)"
          (focus)="handleFocus()"
          (blur)="handleBlur($event)"
        ></textarea>
      </div>
      <span
        *ngIf="helperText && !errorMessage"
        class="ksaa-textarea__helper"
        [attr.id]="inputId ? inputId + '-helper' : null"
      >{{ helperText }}</span>
      <span
        *ngIf="errorMessage"
        class="ksaa-textarea__error"
        [attr.id]="inputId ? inputId + '-error' : null"
      >{{ errorMessage }}</span>
    </label>
  `, styles: [":host{display:inline-block;font-family:var(--font-family-ibm-plex-sans-arabic)}.ksaa-textarea{display:flex;flex-direction:column;gap:4px;color:var(--color-gray-900)}.ksaa-textarea__label{font-size:var(--text-sm-medium-font-size);font-weight:var(--text-sm-semibold-font-weight)}.ksaa-textarea__required{color:var(--color-error-default);margin-inline-start:2px}.ksaa-textarea__field{position:relative;display:flex}.ksaa-textarea__control{width:100%;border:1px solid var(--color-gray-300);border-radius:var(--radius-sm);background:var(--color-white);color:var(--color-gray-900);font-size:var(--text-sm-medium-font-size);line-height:1.4;transition:border-color .14s ease,box-shadow .14s ease,background-color .14s ease;box-shadow:0 1px 2px #0f172a0d;padding:10px 12px;resize:vertical;min-height:96px}.ksaa-textarea__control::placeholder{color:var(--color-gray-400)}.ksaa-textarea__control:focus-visible{outline:none}.ksaa-textarea:not(.ksaa-textarea--disabled):not(.ksaa-textarea--readonly) .ksaa-textarea__control:hover,.ksaa-textarea--hover .ksaa-textarea__control{border-color:var(--color-field-border-hover)}.ksaa-textarea--focused .ksaa-textarea__control,.ksaa-textarea__control:focus-visible{border-color:var(--color-field-border-hover);box-shadow:0 1px 1px 0 var(--color-default)}.ksaa-textarea__helper{font-size:var(--text-xs-medium-font-size);color:var(--color-gray-600)}.ksaa-textarea__error{font-size:var(--text-xs-medium-font-size);color:var(--color-error-default);font-weight:var(--text-sm-semibold-font-weight)}.ksaa-textarea--error .ksaa-textarea__control{border-color:var(--color-error-default);box-shadow:0 0 0 2px #b4231829}.ksaa-textarea--disabled{opacity:.6;cursor:not-allowed}.ksaa-textarea--disabled .ksaa-textarea__control{background:var(--color-gray-50);border-color:var(--color-gray-200);color:var(--color-gray-400);box-shadow:none}.ksaa-textarea--disabled .ksaa-textarea__label,.ksaa-textarea--disabled .ksaa-textarea__helper{color:var(--color-gray-400)}.ksaa-textarea--readonly .ksaa-textarea__control{background:var(--color-gray-100);border-color:var(--color-gray-200);color:var(--color-gray-700)}.ksaa-textarea--small .ksaa-textarea__control{padding:6px 10px;font-size:var(--text-xs-medium-font-size);min-height:72px}.ksaa-textarea--large .ksaa-textarea__control{padding:12px 14px;font-size:var(--text-md-medium-font-size);min-height:120px}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], value: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], helperText: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], name: [{
                type: Input
            }], inputId: [{
                type: Input
            }], dir: [{
                type: Input
            }], size: [{
                type: Input
            }], state: [{
                type: Input
            }], disabled: [{
                type: Input
            }], readonly: [{
                type: Input
            }], required: [{
                type: Input
            }], rows: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], onInput: [{
                type: Output
            }], onBlur: [{
                type: Output
            }] } });

class KsaaTextInputComponent {
    /** Field label */
    label = 'Label';
    /** Input value */
    value = '';
    /** Placeholder text */
    placeholder = 'Entered text';
    /** Helper text below the input */
    helperText = '';
    /** Error message displayed below the input */
    errorMessage = '';
    /** Input type attribute */
    type = 'text';
    /** Input name attribute */
    name;
    /** Input id attribute */
    inputId;
    /** Direction of the text flow */
    dir = 'ltr';
    /** Visual size of the input */
    size = 'medium';
    /** Force a visual state for Storybook */
    state = 'default';
    /** Disable interactions */
    disabled = false;
    /** Mark the input as read-only */
    readonly = false;
    /** Shows a required indicator */
    required = false;
    /** Emits the current value */
    valueChange = new EventEmitter();
    /** Emits the native input event */
    onInput = new EventEmitter();
    /** Emits the native blur event */
    onBlur = new EventEmitter();
    isFocused = false;
    onChangeFn = () => { };
    onTouchedFn = () => { };
    get describedById() {
        if (this.errorMessage) {
            return this.inputId ? `${this.inputId}-error` : null;
        }
        if (this.helperText) {
            return this.inputId ? `${this.inputId}-helper` : null;
        }
        return null;
    }
    handleInput(event) {
        const target = event.target;
        this.value = target.value;
        this.valueChange.emit(this.value);
        this.onInput.emit(event);
        this.onChangeFn(this.value);
    }
    handleFocus() {
        this.isFocused = true;
    }
    handleBlur(event) {
        this.isFocused = false;
        this.onTouchedFn();
        this.onBlur.emit(event);
    }
    writeValue(value) {
        this.value = value ?? '';
    }
    registerOnChange(fn) {
        this.onChangeFn = fn;
    }
    registerOnTouched(fn) {
        this.onTouchedFn = fn;
    }
    setDisabledState(isDisabled) {
        this.disabled = isDisabled;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaTextInputComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.3", type: KsaaTextInputComponent, isStandalone: true, selector: "ksaa-text-input", inputs: { label: "label", value: "value", placeholder: "placeholder", helperText: "helperText", errorMessage: "errorMessage", type: "type", name: "name", inputId: "inputId", dir: "dir", size: "size", state: "state", disabled: "disabled", readonly: "readonly", required: "required" }, outputs: { valueChange: "valueChange", onInput: "onInput", onBlur: "onBlur" }, providers: [
            {
                provide: NG_VALUE_ACCESSOR,
                useExisting: forwardRef(() => KsaaTextInputComponent),
                multi: true,
            },
        ], ngImport: i0, template: `
    <label
      class="ksaa-text-input"
      [ngClass]="[
        'ksaa-text-input--' + size,
        errorMessage ? 'ksaa-text-input--error' : '',
        disabled ? 'ksaa-text-input--disabled' : '',
        readonly ? 'ksaa-text-input--readonly' : '',
        state === 'hover' ? 'ksaa-text-input--hover' : '',
        state === 'focus' || isFocused ? 'ksaa-text-input--focused' : ''
      ]"
      [attr.dir]="dir"
    >
      <span class="ksaa-text-input__label" *ngIf="label">
        {{ label }}
        <span *ngIf="required" class="ksaa-text-input__required" aria-hidden="true">*</span>
      </span>
      <div class="ksaa-text-input__field">
        <input
          class="ksaa-text-input__control"
          [attr.type]="type"
          [attr.placeholder]="placeholder"
          [attr.name]="name"
          [attr.id]="inputId"
          [attr.aria-invalid]="errorMessage ? 'true' : null"
          [attr.aria-describedby]="describedById"
          [disabled]="disabled"
          [readonly]="readonly"
          [value]="value"
          (input)="handleInput($event)"
          (focus)="handleFocus()"
          (blur)="handleBlur($event)"
        />
      </div>
      <span
        *ngIf="helperText && !errorMessage"
        class="ksaa-text-input__helper"
        [attr.id]="inputId ? inputId + '-helper' : null"
      >{{ helperText }}</span>
      <span
        *ngIf="errorMessage"
        class="ksaa-text-input__error"
        [attr.id]="inputId ? inputId + '-error' : null"
      >{{ errorMessage }}</span>
    </label>
  `, isInline: true, styles: [":host{display:inline-block;font-family:var(--font-family-ibm-plex-sans-arabic)}.ksaa-text-input{display:flex;flex-direction:column;gap:4px;color:var(--color-gray-900)}.ksaa-text-input__label{font-size:var(--text-sm-medium-font-size);font-weight:var(--text-sm-semibold-font-weight)}.ksaa-text-input__required{color:var(--color-error-default);margin-inline-start:2px}.ksaa-text-input__field{position:relative;display:flex}.ksaa-text-input__control{width:100%;border:1px solid var(--color-gray-300);border-radius:var(--radius-sm);background:var(--color-white);color:var(--color-gray-900);font-size:var(--text-sm-medium-font-size);line-height:1.4;transition:border-color .14s ease,box-shadow .14s ease,background-color .14s ease;box-shadow:0 1px 2px #0f172a0d;padding:10px 12px}.ksaa-text-input__control::placeholder{color:var(--color-gray-400)}.ksaa-text-input__control:focus-visible{outline:none}.ksaa-text-input:not(.ksaa-text-input--disabled):not(.ksaa-text-input--readonly) .ksaa-text-input__control:hover,.ksaa-text-input--hover .ksaa-text-input__control{border-color:var(--color-field-border-hover)}.ksaa-text-input--focused .ksaa-text-input__control,.ksaa-text-input__control:focus-visible{border-color:var(--color-field-border-hover);box-shadow:0 1px 1px 0 var(--color-default)}.ksaa-text-input__helper{font-size:var(--text-xs-medium-font-size);color:var(--color-gray-600)}.ksaa-text-input__error{font-size:var(--text-xs-medium-font-size);color:var(--color-error-default);font-weight:var(--text-sm-semibold-font-weight)}.ksaa-text-input--error .ksaa-text-input__control{border-color:var(--color-error-default);box-shadow:0 0 0 2px #b4231829}.ksaa-text-input--disabled{opacity:.6;cursor:not-allowed}.ksaa-text-input--disabled .ksaa-text-input__control{background:var(--color-gray-50);border-color:var(--color-gray-200);color:var(--color-gray-400);box-shadow:none}.ksaa-text-input--disabled .ksaa-text-input__label,.ksaa-text-input--disabled .ksaa-text-input__helper{color:var(--color-gray-400)}.ksaa-text-input--readonly .ksaa-text-input__control{background:var(--color-gray-100);border-color:var(--color-gray-200);color:var(--color-gray-700)}.ksaa-text-input--small .ksaa-text-input__control{padding:6px 10px;font-size:var(--text-xs-medium-font-size)}.ksaa-text-input--large .ksaa-text-input__control{padding:12px 14px;font-size:var(--text-md-medium-font-size)}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaTextInputComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ksaa-text-input', standalone: true, imports: [CommonModule], providers: [
                        {
                            provide: NG_VALUE_ACCESSOR,
                            useExisting: forwardRef(() => KsaaTextInputComponent),
                            multi: true,
                        },
                    ], template: `
    <label
      class="ksaa-text-input"
      [ngClass]="[
        'ksaa-text-input--' + size,
        errorMessage ? 'ksaa-text-input--error' : '',
        disabled ? 'ksaa-text-input--disabled' : '',
        readonly ? 'ksaa-text-input--readonly' : '',
        state === 'hover' ? 'ksaa-text-input--hover' : '',
        state === 'focus' || isFocused ? 'ksaa-text-input--focused' : ''
      ]"
      [attr.dir]="dir"
    >
      <span class="ksaa-text-input__label" *ngIf="label">
        {{ label }}
        <span *ngIf="required" class="ksaa-text-input__required" aria-hidden="true">*</span>
      </span>
      <div class="ksaa-text-input__field">
        <input
          class="ksaa-text-input__control"
          [attr.type]="type"
          [attr.placeholder]="placeholder"
          [attr.name]="name"
          [attr.id]="inputId"
          [attr.aria-invalid]="errorMessage ? 'true' : null"
          [attr.aria-describedby]="describedById"
          [disabled]="disabled"
          [readonly]="readonly"
          [value]="value"
          (input)="handleInput($event)"
          (focus)="handleFocus()"
          (blur)="handleBlur($event)"
        />
      </div>
      <span
        *ngIf="helperText && !errorMessage"
        class="ksaa-text-input__helper"
        [attr.id]="inputId ? inputId + '-helper' : null"
      >{{ helperText }}</span>
      <span
        *ngIf="errorMessage"
        class="ksaa-text-input__error"
        [attr.id]="inputId ? inputId + '-error' : null"
      >{{ errorMessage }}</span>
    </label>
  `, styles: [":host{display:inline-block;font-family:var(--font-family-ibm-plex-sans-arabic)}.ksaa-text-input{display:flex;flex-direction:column;gap:4px;color:var(--color-gray-900)}.ksaa-text-input__label{font-size:var(--text-sm-medium-font-size);font-weight:var(--text-sm-semibold-font-weight)}.ksaa-text-input__required{color:var(--color-error-default);margin-inline-start:2px}.ksaa-text-input__field{position:relative;display:flex}.ksaa-text-input__control{width:100%;border:1px solid var(--color-gray-300);border-radius:var(--radius-sm);background:var(--color-white);color:var(--color-gray-900);font-size:var(--text-sm-medium-font-size);line-height:1.4;transition:border-color .14s ease,box-shadow .14s ease,background-color .14s ease;box-shadow:0 1px 2px #0f172a0d;padding:10px 12px}.ksaa-text-input__control::placeholder{color:var(--color-gray-400)}.ksaa-text-input__control:focus-visible{outline:none}.ksaa-text-input:not(.ksaa-text-input--disabled):not(.ksaa-text-input--readonly) .ksaa-text-input__control:hover,.ksaa-text-input--hover .ksaa-text-input__control{border-color:var(--color-field-border-hover)}.ksaa-text-input--focused .ksaa-text-input__control,.ksaa-text-input__control:focus-visible{border-color:var(--color-field-border-hover);box-shadow:0 1px 1px 0 var(--color-default)}.ksaa-text-input__helper{font-size:var(--text-xs-medium-font-size);color:var(--color-gray-600)}.ksaa-text-input__error{font-size:var(--text-xs-medium-font-size);color:var(--color-error-default);font-weight:var(--text-sm-semibold-font-weight)}.ksaa-text-input--error .ksaa-text-input__control{border-color:var(--color-error-default);box-shadow:0 0 0 2px #b4231829}.ksaa-text-input--disabled{opacity:.6;cursor:not-allowed}.ksaa-text-input--disabled .ksaa-text-input__control{background:var(--color-gray-50);border-color:var(--color-gray-200);color:var(--color-gray-400);box-shadow:none}.ksaa-text-input--disabled .ksaa-text-input__label,.ksaa-text-input--disabled .ksaa-text-input__helper{color:var(--color-gray-400)}.ksaa-text-input--readonly .ksaa-text-input__control{background:var(--color-gray-100);border-color:var(--color-gray-200);color:var(--color-gray-700)}.ksaa-text-input--small .ksaa-text-input__control{padding:6px 10px;font-size:var(--text-xs-medium-font-size)}.ksaa-text-input--large .ksaa-text-input__control{padding:12px 14px;font-size:var(--text-md-medium-font-size)}\n"] }]
        }], propDecorators: { label: [{
                type: Input
            }], value: [{
                type: Input
            }], placeholder: [{
                type: Input
            }], helperText: [{
                type: Input
            }], errorMessage: [{
                type: Input
            }], type: [{
                type: Input
            }], name: [{
                type: Input
            }], inputId: [{
                type: Input
            }], dir: [{
                type: Input
            }], size: [{
                type: Input
            }], state: [{
                type: Input
            }], disabled: [{
                type: Input
            }], readonly: [{
                type: Input
            }], required: [{
                type: Input
            }], valueChange: [{
                type: Output
            }], onInput: [{
                type: Output
            }], onBlur: [{
                type: Output
            }] } });

class KsaaModalComponent {
    static nextId = 0;
    /** Modal title text */
    title;
    /** Supporting description below the title */
    description;
    /** Direction of the modal content */
    dir = 'ltr';
    /** Modal size width */
    size = 'large';
    /** Action buttons layout */
    actionsLayout = 'horizontal';
    /** Position within its container */
    position = 'top-center';
    /** Display the leading icon */
    showIcon = true;
    /** Icon text rendered inside the leading badge */
    iconText = 'i';
    /** Accessible label for the close button */
    closeLabel = 'Close dialog';
    /** Toggle the close button */
    showClose = true;
    /** Base id used for aria attributes */
    modalId = `ksaa-modal-${KsaaModalComponent.nextId++}`;
    /** Emits when the close icon is clicked */
    onClose = new EventEmitter();
    get titleId() {
        return `${this.modalId}-title`;
    }
    get descriptionId() {
        return `${this.modalId}-description`;
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaModalComponent, deps: [], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.3", type: KsaaModalComponent, isStandalone: true, selector: "ksaa-modal", inputs: { title: "title", description: "description", dir: "dir", size: "size", actionsLayout: "actionsLayout", position: "position", showIcon: "showIcon", iconText: "iconText", closeLabel: "closeLabel", showClose: "showClose", modalId: "modalId" }, outputs: { onClose: "onClose" }, ngImport: i0, template: `
    <section
      class="ksaa-modal"
      [ngClass]="[
        'ksaa-modal--' + size,
        'ksaa-modal--position-' + position,
        actionsLayout === 'stacked' ? 'ksaa-modal--stacked' : ''
      ]"
      [attr.dir]="dir"
      role="dialog"
      aria-modal="true"
      [attr.aria-labelledby]="title ? titleId : null"
      [attr.aria-describedby]="description ? descriptionId : null"
    >
      <header class="ksaa-modal__header">
        <div *ngIf="showIcon" class="ksaa-modal__icon" aria-hidden="true">
          <span class="ksaa-modal__icon-text">{{ iconText }}</span>
        </div>
        <button
          *ngIf="showClose"
          class="ksaa-modal__close"
          type="button"
          [attr.aria-label]="closeLabel"
          (click)="onClose.emit($event)"
        >
          ×
        </button>
      </header>
      <div class="ksaa-modal__content">
        <h3 *ngIf="title" class="ksaa-modal__title" [id]="titleId">{{ title }}</h3>
        <p *ngIf="description" class="ksaa-modal__description" [id]="descriptionId">
          {{ description }}
        </p>
        <ng-content></ng-content>
      </div>
      <div class="ksaa-modal__actions" [ngClass]="'ksaa-modal__actions--' + actionsLayout">
        <ng-content select="[modal-actions]"></ng-content>
      </div>
    </section>
  `, isInline: true, styles: [":host{display:block;font-family:var(--font-family-ibm-plex-sans-arabic)}.ksaa-modal{background:var(--color-white);border-radius:16px;border:1px solid var(--color-gray-200);box-shadow:0 24px 48px #0f172a2e;padding:24px;color:var(--color-gray-900);display:flex;flex-direction:column;gap:16px;margin-inline:auto}.ksaa-modal--small{width:360px}.ksaa-modal--medium{width:480px}.ksaa-modal--large{width:680px}.ksaa-modal--position-top-center{margin-top:0;margin-bottom:auto}.ksaa-modal--position-center{margin-block:auto}.ksaa-modal--position-bottom-center{margin-top:auto;margin-bottom:0}.ksaa-modal__header{display:flex;align-items:center;justify-content:space-between;gap:12px}.ksaa-modal__icon{width:32px;height:32px;border-radius:50%;border:1px solid var(--color-gray-300);display:inline-flex;align-items:center;justify-content:center;color:var(--color-gray-700);background:var(--color-white)}.ksaa-modal__icon-text{font-size:14px;font-weight:700;line-height:1}.ksaa-modal__close{border:none;background:transparent;color:var(--color-gray-700);font-size:20px;line-height:1;cursor:pointer;padding:4px;border-radius:8px}.ksaa-modal__close:focus-visible{outline:2px solid var(--color-primary-default);outline-offset:2px}.ksaa-modal__content{display:flex;flex-direction:column;gap:8px;text-align:start}.ksaa-modal__title{margin:0;font-size:20px;font-weight:700;line-height:1.4}.ksaa-modal__description{margin:0;font-size:14px;line-height:1.6;color:var(--color-gray-600)}.ksaa-modal__actions{display:flex;gap:12px}.ksaa-modal__actions--horizontal{justify-content:flex-end;flex-wrap:wrap}.ksaa-modal__actions--stacked{flex-direction:column;align-items:stretch}:host([dir=\"rtl\"]) .ksaa-modal__actions--horizontal{flex-direction:row-reverse;justify-content:flex-start}:host([dir=\"rtl\"]) .ksaa-modal__close{margin-left:auto}@media(max-width:768px){.ksaa-modal{width:100%;max-width:100%}}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaModalComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ksaa-modal', standalone: true, imports: [CommonModule], template: `
    <section
      class="ksaa-modal"
      [ngClass]="[
        'ksaa-modal--' + size,
        'ksaa-modal--position-' + position,
        actionsLayout === 'stacked' ? 'ksaa-modal--stacked' : ''
      ]"
      [attr.dir]="dir"
      role="dialog"
      aria-modal="true"
      [attr.aria-labelledby]="title ? titleId : null"
      [attr.aria-describedby]="description ? descriptionId : null"
    >
      <header class="ksaa-modal__header">
        <div *ngIf="showIcon" class="ksaa-modal__icon" aria-hidden="true">
          <span class="ksaa-modal__icon-text">{{ iconText }}</span>
        </div>
        <button
          *ngIf="showClose"
          class="ksaa-modal__close"
          type="button"
          [attr.aria-label]="closeLabel"
          (click)="onClose.emit($event)"
        >
          ×
        </button>
      </header>
      <div class="ksaa-modal__content">
        <h3 *ngIf="title" class="ksaa-modal__title" [id]="titleId">{{ title }}</h3>
        <p *ngIf="description" class="ksaa-modal__description" [id]="descriptionId">
          {{ description }}
        </p>
        <ng-content></ng-content>
      </div>
      <div class="ksaa-modal__actions" [ngClass]="'ksaa-modal__actions--' + actionsLayout">
        <ng-content select="[modal-actions]"></ng-content>
      </div>
    </section>
  `, styles: [":host{display:block;font-family:var(--font-family-ibm-plex-sans-arabic)}.ksaa-modal{background:var(--color-white);border-radius:16px;border:1px solid var(--color-gray-200);box-shadow:0 24px 48px #0f172a2e;padding:24px;color:var(--color-gray-900);display:flex;flex-direction:column;gap:16px;margin-inline:auto}.ksaa-modal--small{width:360px}.ksaa-modal--medium{width:480px}.ksaa-modal--large{width:680px}.ksaa-modal--position-top-center{margin-top:0;margin-bottom:auto}.ksaa-modal--position-center{margin-block:auto}.ksaa-modal--position-bottom-center{margin-top:auto;margin-bottom:0}.ksaa-modal__header{display:flex;align-items:center;justify-content:space-between;gap:12px}.ksaa-modal__icon{width:32px;height:32px;border-radius:50%;border:1px solid var(--color-gray-300);display:inline-flex;align-items:center;justify-content:center;color:var(--color-gray-700);background:var(--color-white)}.ksaa-modal__icon-text{font-size:14px;font-weight:700;line-height:1}.ksaa-modal__close{border:none;background:transparent;color:var(--color-gray-700);font-size:20px;line-height:1;cursor:pointer;padding:4px;border-radius:8px}.ksaa-modal__close:focus-visible{outline:2px solid var(--color-primary-default);outline-offset:2px}.ksaa-modal__content{display:flex;flex-direction:column;gap:8px;text-align:start}.ksaa-modal__title{margin:0;font-size:20px;font-weight:700;line-height:1.4}.ksaa-modal__description{margin:0;font-size:14px;line-height:1.6;color:var(--color-gray-600)}.ksaa-modal__actions{display:flex;gap:12px}.ksaa-modal__actions--horizontal{justify-content:flex-end;flex-wrap:wrap}.ksaa-modal__actions--stacked{flex-direction:column;align-items:stretch}:host([dir=\"rtl\"]) .ksaa-modal__actions--horizontal{flex-direction:row-reverse;justify-content:flex-start}:host([dir=\"rtl\"]) .ksaa-modal__close{margin-left:auto}@media(max-width:768px){.ksaa-modal{width:100%;max-width:100%}}\n"] }]
        }], propDecorators: { title: [{
                type: Input
            }], description: [{
                type: Input
            }], dir: [{
                type: Input
            }], size: [{
                type: Input
            }], actionsLayout: [{
                type: Input
            }], position: [{
                type: Input
            }], showIcon: [{
                type: Input
            }], iconText: [{
                type: Input
            }], closeLabel: [{
                type: Input
            }], showClose: [{
                type: Input
            }], modalId: [{
                type: Input
            }], onClose: [{
                type: Output
            }] } });

class KsaaAccordionComponent {
    cdr;
    contentSlot;
    titleSlot;
    hasProjectedContent = false;
    hasProjectedTitle = false;
    /** Accordion heading label */
    title = 'Accordion Title';
    /** Supporting content shown when expanded */
    description = 'The accordion component delivers large amounts of content in a small space through progressive disclosure. The user gets key details about the underlying content and can choose to expand that content within the constraints of the accordion.';
    /** Toggle expanded state */
    expanded = false;
    /** Apply muted surface styling */
    muted = false;
    /** Disable the accordion */
    disabled = false;
    /** Force hovered state for documentation */
    hovered = false;
    /** Force focused state for documentation */
    focused = false;
    /** Text direction */
    dir = 'rtl';
    /** Emits when the accordion is toggled */
    toggled = new EventEmitter();
    constructor(cdr) {
        this.cdr = cdr;
    }
    ngAfterViewInit() {
        this.updateProjectedContent();
        this.cdr.detectChanges();
    }
    toggle() {
        if (this.disabled) {
            return;
        }
        this.expanded = !this.expanded;
        this.toggled.emit(this.expanded);
    }
    updateProjectedContent() {
        const container = this.contentSlot?.nativeElement;
        if (!container) {
            this.hasProjectedContent = false;
        }
        else {
            this.hasProjectedContent = this.hasMeaningfulNodes(container);
        }
        const titleContainer = this.titleSlot?.nativeElement;
        this.hasProjectedTitle = titleContainer ? this.hasMeaningfulNodes(titleContainer) : false;
    }
    hasMeaningfulNodes(container) {
        return Array.from(container.childNodes).some((node) => {
            if (node.nodeType === Node.TEXT_NODE) {
                return Boolean(node.textContent?.trim());
            }
            return node.nodeType === Node.ELEMENT_NODE;
        });
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaAccordionComponent, deps: [{ token: i0.ChangeDetectorRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "14.0.0", version: "21.0.3", type: KsaaAccordionComponent, isStandalone: true, selector: "ksaa-accordion", inputs: { title: "title", description: "description", expanded: "expanded", muted: "muted", disabled: "disabled", hovered: "hovered", focused: "focused", dir: "dir" }, outputs: { toggled: "toggled" }, viewQueries: [{ propertyName: "contentSlot", first: true, predicate: ["contentSlot"], descendants: true, read: ElementRef }, { propertyName: "titleSlot", first: true, predicate: ["titleSlot"], descendants: true, read: ElementRef }], ngImport: i0, template: `
    <section
      class="ksaa-accordion"
      [ngClass]="{
        'ksaa-accordion--expanded': expanded,
        'ksaa-accordion--muted': muted,
        'ksaa-accordion--disabled': disabled,
        'ksaa-accordion--hovered': hovered,
        'ksaa-accordion--focused': focused
      }"
      [attr.dir]="dir"
    >
      <button
        type="button"
        class="ksaa-accordion__header"
        [attr.aria-expanded]="expanded"
        [disabled]="disabled"
        (click)="toggle()"
      >
        <span class="ksaa-accordion__title">
          <span #titleSlot class="ksaa-accordion__title-slot">
            <ng-content select="[accordion-title]"></ng-content>
          </span>
          <span *ngIf="!hasProjectedTitle">{{ title }}</span>
        </span>
        <span class="ksaa-accordion__icon" aria-hidden="true">
          <svg
            width="14"
            height="14"
            viewBox="0 0 20 20"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M5 8L10 13L15 8"
              stroke="currentColor"
              stroke-width="1.8"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </span>
      </button>

      <div
        class="ksaa-accordion__content"
        [class.ksaa-accordion__content--expanded]="expanded"
        [attr.aria-hidden]="!expanded"
      >
        <div class="ksaa-accordion__content-inner">
          <div #contentSlot class="ksaa-accordion__content-slot">
            <ng-content></ng-content>
          </div>
          <p *ngIf="!hasProjectedContent" class="ksaa-accordion__description">
            {{ description }}
          </p>
        </div>
      </div>
    </section>
  `, isInline: true, styles: [":host{display:block;width:100%}.ksaa-accordion{border:1px solid var(--color-gray-200, #e5e7eb);border-radius:var(--radius-md, 10px);background:var(--color-white, #ffffff);color:var(--color-gray-900, #111827);font-family:var( --font-sm-medium-font-family, \"Inter\", \"Segoe UI\", system-ui, -apple-system, sans-serif );box-shadow:0 1px 0 0 var(--color-gray-200, #e5e7eb);overflow:hidden}.ksaa-accordion__header{width:100%;border:none;background:transparent;padding:var(--spacing-lg, 12px) var(--spacing-xl, 16px);display:flex;align-items:center;justify-content:space-between;gap:12px;font-size:var(--text-sm-medium-font-size, 14px);font-weight:var(--text-sm-semibold-font-weight, 600);color:inherit;cursor:pointer}.ksaa-accordion__header:focus-visible{outline:2px solid var(--color-gray-900, #111827);outline-offset:-2px}.ksaa-accordion--hovered .ksaa-accordion__header,.ksaa-accordion__header:hover{background:var(--color-gray-100, #f3f4f6)}.ksaa-accordion--focused .ksaa-accordion__header{box-shadow:inset 0 0 0 1px var(--color-gray-900, #111827)}.ksaa-accordion__title{font-size:var(--text-sm-medium-font-size, 14px);font-weight:var(--text-sm-semibold-font-weight, 600)}.ksaa-accordion__icon{display:inline-flex;align-items:center;justify-content:center;color:var(--color-gray-500, #6b7280);transition:transform .15s ease,color .15s ease}.ksaa-accordion--expanded .ksaa-accordion__icon{transform:rotate(180deg);color:var(--color-gray-900, #111827)}.ksaa-accordion__content{border-top:1px solid transparent;padding:0 var(--spacing-xl, 16px);background:var(--color-white, #ffffff);display:grid;grid-template-rows:0fr;transition:grid-template-rows .2s ease,padding .2s ease,border-top-color .2s ease;overflow:hidden}.ksaa-accordion__content-inner{overflow:hidden}.ksaa-accordion__content--expanded{border-top-color:var(--color-gray-200, #e5e7eb);padding:var(--spacing-lg, 12px) var(--spacing-xl, 16px) var(--spacing-xl, 16px);grid-template-rows:1fr}.ksaa-accordion__description{margin:0;font-size:var(--text-xs-medium-font-size, 13px);line-height:1.6;color:var(--color-gray-600, #4b5563)}.ksaa-accordion--muted,.ksaa-accordion--muted .ksaa-accordion__content{background:var(--color-gray-100, #f3f4f6)}.ksaa-accordion--disabled{color:var(--color-neutral-400, #9ca3af);border-color:var(--color-gray-200, #e5e7eb);box-shadow:none}.ksaa-accordion--disabled .ksaa-accordion__header{cursor:not-allowed}.ksaa-accordion--disabled .ksaa-accordion__icon{color:var(--color-neutral-400, #9ca3af)}.ksaa-accordion[dir=rtl] .ksaa-accordion__header{text-align:right}\n"], dependencies: [{ kind: "ngmodule", type: CommonModule }, { kind: "directive", type: i1.NgClass, selector: "[ngClass]", inputs: ["class", "ngClass"] }, { kind: "directive", type: i1.NgIf, selector: "[ngIf]", inputs: ["ngIf", "ngIfThen", "ngIfElse"] }] });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.0.3", ngImport: i0, type: KsaaAccordionComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ksaa-accordion', standalone: true, imports: [CommonModule], template: `
    <section
      class="ksaa-accordion"
      [ngClass]="{
        'ksaa-accordion--expanded': expanded,
        'ksaa-accordion--muted': muted,
        'ksaa-accordion--disabled': disabled,
        'ksaa-accordion--hovered': hovered,
        'ksaa-accordion--focused': focused
      }"
      [attr.dir]="dir"
    >
      <button
        type="button"
        class="ksaa-accordion__header"
        [attr.aria-expanded]="expanded"
        [disabled]="disabled"
        (click)="toggle()"
      >
        <span class="ksaa-accordion__title">
          <span #titleSlot class="ksaa-accordion__title-slot">
            <ng-content select="[accordion-title]"></ng-content>
          </span>
          <span *ngIf="!hasProjectedTitle">{{ title }}</span>
        </span>
        <span class="ksaa-accordion__icon" aria-hidden="true">
          <svg
            width="14"
            height="14"
            viewBox="0 0 20 20"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <path
              d="M5 8L10 13L15 8"
              stroke="currentColor"
              stroke-width="1.8"
              stroke-linecap="round"
              stroke-linejoin="round"
            />
          </svg>
        </span>
      </button>

      <div
        class="ksaa-accordion__content"
        [class.ksaa-accordion__content--expanded]="expanded"
        [attr.aria-hidden]="!expanded"
      >
        <div class="ksaa-accordion__content-inner">
          <div #contentSlot class="ksaa-accordion__content-slot">
            <ng-content></ng-content>
          </div>
          <p *ngIf="!hasProjectedContent" class="ksaa-accordion__description">
            {{ description }}
          </p>
        </div>
      </div>
    </section>
  `, styles: [":host{display:block;width:100%}.ksaa-accordion{border:1px solid var(--color-gray-200, #e5e7eb);border-radius:var(--radius-md, 10px);background:var(--color-white, #ffffff);color:var(--color-gray-900, #111827);font-family:var( --font-sm-medium-font-family, \"Inter\", \"Segoe UI\", system-ui, -apple-system, sans-serif );box-shadow:0 1px 0 0 var(--color-gray-200, #e5e7eb);overflow:hidden}.ksaa-accordion__header{width:100%;border:none;background:transparent;padding:var(--spacing-lg, 12px) var(--spacing-xl, 16px);display:flex;align-items:center;justify-content:space-between;gap:12px;font-size:var(--text-sm-medium-font-size, 14px);font-weight:var(--text-sm-semibold-font-weight, 600);color:inherit;cursor:pointer}.ksaa-accordion__header:focus-visible{outline:2px solid var(--color-gray-900, #111827);outline-offset:-2px}.ksaa-accordion--hovered .ksaa-accordion__header,.ksaa-accordion__header:hover{background:var(--color-gray-100, #f3f4f6)}.ksaa-accordion--focused .ksaa-accordion__header{box-shadow:inset 0 0 0 1px var(--color-gray-900, #111827)}.ksaa-accordion__title{font-size:var(--text-sm-medium-font-size, 14px);font-weight:var(--text-sm-semibold-font-weight, 600)}.ksaa-accordion__icon{display:inline-flex;align-items:center;justify-content:center;color:var(--color-gray-500, #6b7280);transition:transform .15s ease,color .15s ease}.ksaa-accordion--expanded .ksaa-accordion__icon{transform:rotate(180deg);color:var(--color-gray-900, #111827)}.ksaa-accordion__content{border-top:1px solid transparent;padding:0 var(--spacing-xl, 16px);background:var(--color-white, #ffffff);display:grid;grid-template-rows:0fr;transition:grid-template-rows .2s ease,padding .2s ease,border-top-color .2s ease;overflow:hidden}.ksaa-accordion__content-inner{overflow:hidden}.ksaa-accordion__content--expanded{border-top-color:var(--color-gray-200, #e5e7eb);padding:var(--spacing-lg, 12px) var(--spacing-xl, 16px) var(--spacing-xl, 16px);grid-template-rows:1fr}.ksaa-accordion__description{margin:0;font-size:var(--text-xs-medium-font-size, 13px);line-height:1.6;color:var(--color-gray-600, #4b5563)}.ksaa-accordion--muted,.ksaa-accordion--muted .ksaa-accordion__content{background:var(--color-gray-100, #f3f4f6)}.ksaa-accordion--disabled{color:var(--color-neutral-400, #9ca3af);border-color:var(--color-gray-200, #e5e7eb);box-shadow:none}.ksaa-accordion--disabled .ksaa-accordion__header{cursor:not-allowed}.ksaa-accordion--disabled .ksaa-accordion__icon{color:var(--color-neutral-400, #9ca3af)}.ksaa-accordion[dir=rtl] .ksaa-accordion__header{text-align:right}\n"] }]
        }], ctorParameters: () => [{ type: i0.ChangeDetectorRef }], propDecorators: { contentSlot: [{
                type: ViewChild,
                args: ['contentSlot', { read: ElementRef }]
            }], titleSlot: [{
                type: ViewChild,
                args: ['titleSlot', { read: ElementRef }]
            }], title: [{
                type: Input
            }], description: [{
                type: Input
            }], expanded: [{
                type: Input
            }], muted: [{
                type: Input
            }], disabled: [{
                type: Input
            }], hovered: [{
                type: Input
            }], focused: [{
                type: Input
            }], dir: [{
                type: Input
            }], toggled: [{
                type: Output
            }] } });

/*
 * Public API Surface of ksaa-dga-ui
 */

/**
 * Generated bundle index. Do not edit.
 */

export { FooterTemplateDirective, KsaaAccordionComponent, KsaaButtonComponent, KsaaCardComponent, KsaaCheckboxComponent, KsaaFooterComponent, KsaaModalComponent, KsaaNavbarComponent, KsaaTextInputComponent, KsaaTextareaComponent, NavbarTemplateDirective };
//# sourceMappingURL=ksaa-dga-ui.mjs.map
